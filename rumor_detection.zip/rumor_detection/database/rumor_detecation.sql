-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 15, 2018 at 06:55 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rumor_detecation`
--

-- --------------------------------------------------------

--
-- Table structure for table `commen`
--

DROP TABLE IF EXISTS `commen`;
CREATE TABLE IF NOT EXISTS `commen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(25) NOT NULL,
  `title` varchar(50) NOT NULL,
  `messag` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `commen`
--

INSERT INTO `commen` (`id`, `email`, `title`, `messag`) VALUES
(1, 'k@gmail.com', 'bghhhgjggy', 'ityugyuggugu'),
(2, 'kjfdsjjkd', 'dsalkdasfkl', 'dsklmdfs;l'),
(3, 'hello ', 'how are you', 'i am fine');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(500) NOT NULL,
  `uid` int(11) NOT NULL,
  `nid` int(11) NOT NULL,
  `operation_date` datetime NOT NULL,
  `operation` varchar(8) NOT NULL,
  `row_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`cid`, `cname`, `uid`, `nid`, `operation_date`, `operation`, `row_delete`) VALUES
(1, 'Hello i lick your comment', 3, 1, '2018-02-14 00:00:42', 'insert', 0),
(2, 'i likeeddf sfldsjfldsmdsfjdkasljkasn jfldsajlkfads. fjdslnflkdsjf s,dsnfndsljf', 3, 4, '2018-02-14 19:23:48', 'insert', 0),
(3, 'kishandsjfands skldfkdsjnfsd sfjldsjf', 8, 3, '2018-02-14 21:16:21', 'insert', 0),
(4, 'jdlfjdslmfds', 3, 10, '2018-02-15 07:47:24', 'insert', 0),
(5, 'yuhhuhn', 3, 11, '2018-02-15 09:03:52', 'insert', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(8) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `operation_date` datetime NOT NULL,
  `operation` varchar(8) NOT NULL,
  `row_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`, `status`, `operation_date`, `operation`, `row_delete`) VALUES
(1, 'Kishan kumar', 'kishan@gmail.com', 'vikash', 2, '2018-02-13 00:00:00', 'insert', 0),
(2, 'Vikash Dewangan', 'vikash@gmail.com', 'ravi', 1, '2018-02-13 00:00:00', 'insert', 0),
(3, 'Ravi', 'ravi@gmail.com', 'kamran', 1, '2018-02-13 11:59:07', 'insert', 0),
(4, 'pooja', 'poojasahu29041996@gmail.com', '123', 2, '2018-02-14 00:00:00', 'insert', 0),
(5, 'shweta rai', 'shwetarai25051999@gmail.com', 'shweta25', 2, '2018-02-14 00:00:00', 'insert', 0),
(6, 'poonam sahu', 'poonam372sahu@gmail.com', 'poonam12', 2, '2018-02-14 00:00:00', 'insert', 0),
(7, 'yasmin', 'bushrayasmin1998@gmail.com', '123', 2, '2018-02-14 00:00:00', 'insert', 0),
(8, 'poonam', 'poonam@gmail.com', 'poonam', 1, '2018-02-14 21:13:11', 'insert', 0),
(9, 'sagar', 'sagar@gmail.com', 'sagar', 1, '2018-02-15 09:17:33', 'insert', 0),
(10, 'manish kumar', 'manish@gmail.com', 'manish', 1, '2018-02-15 12:20:17', 'insert', 0);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `nid` int(11) NOT NULL AUTO_INCREMENT,
  `ntitle` varchar(500) NOT NULL,
  `uid` int(11) NOT NULL,
  `rno` int(11) NOT NULL DEFAULT '0',
  `rid` varchar(10000) DEFAULT NULL,
  `nrno` int(11) NOT NULL DEFAULT '0',
  `nrid` varchar(10000) DEFAULT NULL,
  `adminrno` int(11) NOT NULL DEFAULT '0',
  `adminrid` varchar(10000) DEFAULT NULL,
  `rstatus` int(11) NOT NULL DEFAULT '1',
  `uip` varchar(50) NOT NULL,
  `umac` varchar(50) NOT NULL,
  `operation_date` datetime NOT NULL,
  `operation` varchar(8) NOT NULL,
  `row_delete` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`nid`, `ntitle`, `uid`, `rno`, `rid`, `nrno`, `nrid`, `adminrno`, `adminrid`, `rstatus`, `uip`, `umac`, `operation_date`, `operation`, `row_delete`, `type`) VALUES
(1, 'Bhilai is a good city', 2, 0, NULL, 1, ',3', 2, ',2,8', 1, '192.168.4.126', 'D4-BE-D9-C2-54-C2', '2018-02-13 00:00:00', 'insert', 0, 0),
(2, 'hello', 3, 0, NULL, 0, NULL, 2, ',3,2', 1, '192.168.4.126', 'D4-BE-D9-C2-54-C2', '2018-02-13 13:28:29', 'insert', 1, 0),
(3, 'kisdfhkjfh\r\n', 3, 0, NULL, 1, ',8', 2, ',2,3', 1, '192.168.4.126', 'D4-BE-D9-C2-54-C2', '2018-02-13 13:34:34', 'insert', 0, 0),
(4, 'hghh', 3, 1, ',3', 2, ',2,3', 1, ',3', 0, '100.70.186.30', '00-1E-10-1F-00-00', '2018-02-13 21:50:33', 'insert', 0, 0),
(5, 'kishan kumar\r\n', 3, 0, NULL, 1, ',3', 0, NULL, 0, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-14 18:20:52', 'insert', 1, 0),
(6, 'kishan kumar\r\n', 3, 0, NULL, 1, ',3', 0, NULL, 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-14 18:20:53', 'insert', 0, 0),
(7, 'hello how are you', 3, 0, NULL, 0, NULL, 1, ',3', 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-14 22:31:01', 'insert', 0, 0),
(8, 'Sachin is the best palyer', 8, 0, NULL, 2, ',3,3', 0, NULL, 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-14 23:57:19', 'insert', 0, 5),
(9, 'Sachin is the best palyer', 8, 0, NULL, 0, NULL, 1, ',3', 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-14 23:59:25', 'insert', 0, 5),
(10, 'hjhkm', 3, 0, NULL, 0, NULL, 0, NULL, 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-15 07:45:38', 'insert', 0, 3),
(11, 'kdshdsn sdkjds sdkl', 8, 0, NULL, 1, ',8', 2, ',8,8', 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-15 08:11:01', 'insert', 0, 3),
(12, 'this is the best place', 9, 0, NULL, 2, ',9,9', 1, ',9', 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-15 09:22:05', 'insert', 0, 5),
(13, 'fjdsaljfladsm', 3, 0, NULL, 0, NULL, 0, NULL, 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-15 10:34:32', 'insert', 0, 1),
(14, 'India is the world\'s second largest English speaking country.', 3, 1, ',10', 0, NULL, 1, ',3', 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-15 10:35:11', 'insert', 0, 6),
(15, 'SALT SHARTAGE IN INDIA.', 3, 0, NULL, 1, ',3', 1, ',10', 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-15 10:36:07', 'insert', 0, 6),
(16, 'modi har har', 10, 0, NULL, 0, NULL, 0, NULL, 1, '192.168.5.184', '70-5A-0F-BA-4A-27', '2018-02-15 12:22:53', 'insert', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `typeofrumors`
--

DROP TABLE IF EXISTS `typeofrumors`;
CREATE TABLE IF NOT EXISTS `typeofrumors` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `tname` varchar(30) NOT NULL,
  `tstatus` int(11) NOT NULL DEFAULT '1',
  `row_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `typeofrumors`
--

INSERT INTO `typeofrumors` (`tid`, `tname`, `tstatus`, `row_delete`) VALUES
(1, 'Medical', 1, 0),
(2, 'Political', 1, 0),
(3, 'Programing', 1, 0),
(4, 'Entertanment', 1, 0),
(5, 'Sports', 1, 0),
(6, 'Social', 1, 0),
(7, 'Job', 1, 0),
(0, 'Other', 1, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
