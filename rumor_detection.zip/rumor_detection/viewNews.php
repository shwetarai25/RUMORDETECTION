<?php
require_once "page_header.php";
?>

<div class="uper">
<?php

if(isset($_SESSION['aemail']))
{ 
	require_once "conn.php";
	?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php
if(isset($_REQUEST['delete'])&&($_REQUEST['delete']==5))
{
	echo '<div class="row">
    <div class="container">
 <div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>Well done!</strong>  You successfully post your <strong>Deleted the Post</strong>..
</div>
</div>
</div>';
}
?><br>
<br>
<br>
<br>
<br>
<br>
<button type="button" name="addPost" data-toggle="modal" data-target="#addNews" class="btn btn-info btn-sm">Add News</button>
<br>
<br>
<div class="container-fluid">
	<div class="showTable">
		<table id="showNews"  class="table table-striped table-bordered" cellspacing="0" width="100%"><thead><tr><th>No</th>
			<th>Title</th>
			<th>User</th>
			<th>rumor</th>
			<th>Non Rumor</th>
			<th>Admin validation</th>
			<th>Type</th>
			<th>Total View</th>
			<th>status</th>
			<th>Action</th></tr>
		</thead><tfoot></tfoot><tbody>
			<?php
			$sql='select * from news,login,typeofrumors where uid=id && typeofrumors.tid=news.type && news.row_delete=0';
			$stmt=$db->prepare($sql) or die("not Run");
			$stmt->execute();
			 $k=0;
			while($result=$stmt->fetch())
			{  $k++;
				if(!$result['rstatus']==1)
				{
					$status='Off';
				}
				else
				{
					$status='On';
				}
				$total=$result['rno']+$result['nrno']+$result['adminrno'];
				echo '<tr><td>'.$k.'</td>
				<td>'.$result['ntitle'].'</td>
				<td>'.$result['name'].'</td>
				<td>'.$result['rno'].'</td>
				<td>'.$result['nrno'].'</td>
				<td>'.$result['adminrno'].'</td>
				<td>'.$total.'</td>
				<td>'.$result['tname'].'</td>
				<td><a href="form.php?status=1&&st='.$result['rstatus'].'&&id='.$result['nid'].'" name="status" class="btn btn-warning btn-sm">'.$status.'</a></td>
				<td><a href="form.php?id='.$result['nid'].'&&delete=news" name="delete_news" class="btn btn-danger btn-sm">Delete</button></td>
				</tr>';
		}
			?>

			</tbody>
		</table>
	</div>
</div>
<script src="js/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
$(document).ready(function() {
    $('#showNews').DataTable();
} );
</script>

	<?php
}?>
</div>
<?php
require_once "kfooter.php";
?>


<style>

.navbar
{
	 margin-top: -51px;
}
}

</style>>