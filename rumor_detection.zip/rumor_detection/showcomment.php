<?php
require_once "page_header.php";
?>
<style>
	
</style>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<div class="uper">
<?php

if(isset($_SESSION['aemail']))
{ 
	require_once "conn.php";
	?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php
if(isset($_REQUEST['delete'])&&($_REQUEST['delete']==5))
{
	echo '<div class="row">
    <div class="container">
 <div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>Well done!</strong>  You successfully post your <strong>Deleted the Post</strong>..
</div>
</div>
</div>';
}
?>
<br>
<div class="container-fluid">
	<div class="showTable">
		<table id="showcomment"  class="table table-striped table-bordered" cellspacing="0" width="100%"><thead><tr><th>No</th>
			<th>Comment</th>
			<th>User</th>
			<th>News</th>
			<th>Date</th>
			<th>Action</th></tr>
		</thead><tfoot></tfoot><tbody>
			<?php
			$sql='select cid,cname,name,ntitle,comment.operation_date from comment,news,login where comment.nid=news.nid && comment.uid=login.id  && comment.row_delete=0';
			$stmt=$db->prepare($sql) or die("not Run");
			$stmt->execute();
			 $k=0;
			while($result=$stmt->fetch())
			{  $k++;
				echo '<tr><td>'.$k.'</td>
				<td>'.$result['cname'].'</td>
				<td>'.$result['name'].'</td>
				<td>'.$result['ntitle'].'</td>
				<td>'.$result['operation_date'].'</td>
				
				<td><a href="form.php?id='.$result['cid'].'&&delete=comment" name="delete_comment" class="btn btn-danger btn-sm">Delete</button></td>
				</tr>';
		}
			?>

			</tbody>
		</table>
	</div>
</div>
<script src="js/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
$(document).ready(function() {
    $('#showcomment').DataTable();
} );
</script>

	<?php
}?>
</div>
<?php
require_once "kfooter.php";
?>
<style>
.navbar{
	margin-top: -45px;
}
	</style>}
