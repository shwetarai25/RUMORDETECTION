<?php
session_start();
require_once "conn.php";
?>
<html>
<head>
	<title>Front Page</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-2.0.3.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<style>
	.contain
	{ 
	
		height: 200px;
		border:solid 2px red;
	}
	
	.messtitle
	{
		
		 
		height: 40px;
		
		font-size:25px;
	}
	.postname
	{
		position:relative;
		top:80px;
	font-size:17px;
	color:black;
		left:90px;
     		
		margin-left:70%;
	}
	#comment
	{
		
		position:relative;
		top:80px;
	font-size:17px;
	color:black;
		left:90px;
		margin-left:80%;
		
	}
	#shweta
	{
		position: absolute;
		z-index: 9999999999;
		margin-top: 200px;
		margin-left: 20%;
		color:white;
	
	}
</style>
<div class="container-fluid">
	<table style="margin-top:200px;" border=1 width=90% bordercolor=#000055 style='border-collapse:collapse'  ALIGN=CENTE >
<tr>
<th bgcolor=#000055 > 
	<font color=white ><h3 style="text-align: center";>BLOCK NEWS</h3>
	</th>=
</tr>
<tr>
	
	<td style="position:relative;"><div class="data">
	<?php
	$title=$_REQUEST['title'];
			$sql="select * from news where row_delete=0 && rstatus=1 && ntitle like '%$title%' order by operation_date desc";
			$stmt=$db->query($sql) or die('not run');
		
			while($results=$stmt->fetch())
			{

				echo '<div class="contain">';
				$nid=$results['nid'];
				$r1=explode(',', $results['rid']);
				$r2=explode(',', $results['nrid']);
				$r3=explode(',', $results['adminrid']);

				if(in_array($_SESSION['uid'],$r3))
				{
						echo '<div class="row">
					<div class="col-md-12">
						<div class="messtitle">
						<div class="messsage">'.$results['ntitle'].'</div>
						</div><!--end of the messtitile-->
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="option">

				<input type="radio" name="rumor'.$results['nid'].'"  value="1" onclick="kishan(this);">rumor'.$results['rno'].'

				<input type="radio" name="rumor'.$results['nid'].'" value="2" onclick="kishan(this);">Not rumor'.$results['nrno'].'

				<input type="radio" name="rumor'.$results['nid'].'" value="3" checked onclick="kishan(this);">Dont No'.$results['adminrno'].'

						</div><!--end of optionclass-->
					</div>
					';
					$sql2="select login.name from login,news where login.id=news.uid && nid=:nid";
					$stmto=$db->prepare($sql2) or die("not run");
					$stmto->execute(array(':nid'=>$results['nid']));
					$res=$stmto->fetch();
					$res['name'];
					echo '<div class="postname">Sender Name &nbsp;&nbsp;'.$res['name'].'</div>';
					echo'
				</div><a href="form.php?comment=1&&nid='.$results['nid'].'" id="comment">Comment on this</a>';

				}
				else if(in_array($_SESSION['uid'], $r2))
				{
						echo '<div class="row">
					<div class="col-md-12">
				<div class="messtitle">
						<div class="messsage">'.$results['ntitle'].'</div>
						</div><!--end of the messtitile-->
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="option">
				<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" onclick="kishan(this);">rumor'.$results['rno'].'

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" checked onclick="kishan(this);">Not rumor'.$results['nrno'].'

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No'.$results['adminrno'].'


						</div><!--end of optionclass-->
					</div>
					';
					$sql2="select login.name from login,news where login.id=news.uid && nid=:nid";
					$stmto=$db->prepare($sql2) or die("not run");
					$stmto->execute(array(':nid'=>$results['nid']));
					$res=$stmto->fetch();
					$res['name'];
					echo '<div class="postname">Sender Name &nbsp;&nbsp;'.$res['name'].'</div>';
					echo'
				</div><a href="form.php?comment=1&&nid='.$results['nid'].'" id="comment">Comment on this</a>';
				}
				else if(in_array($_SESSION['uid'], $r1))
				{
						echo '<div class="row">
					<div class="col-md-12">
				<div class="messtitle">
						<div class="messsage">'.$results['ntitle'].'</div>
						</div><!--end of the messtitile-->
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="option">
				<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" checked onclick="kishan(this);">rumor'.$results['rno'].'

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" onclick="kishan(this);">Not rumor'.$results['nrno'].'

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No'.$results['adminrno'].'

						
						</div><!--end of optionclass-->
					</div>
					';
					$sql2="select login.name from login,news where login.id=news.uid && nid=:nid";
					$stmto=$db->prepare($sql2) or die("not run");
					$stmto->execute(array(':nid'=>$results['nid']));
					$res=$stmto->fetch();
					$res['name'];
					echo '<div class="postname">Sender Name &nbsp;&nbsp;'.$res['name'].'</div>';
					echo'
				</div><a href="form.php?comment=1&&nid='.$results['nid'].'" id="comment">Comment on this</a>';
				}
				else{
			
				echo '<div class="row">
					<div class="col-md-12">
				<div class="messtitle">
						<div class="messsage">'.$results['ntitle'].'</div>
						</div><!--end of the messtitile-->
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="option">
				<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">
				<div class="row">
				<div class="col-md-3">
				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" onclick="kishan(this);">'.$results['rno'].'>
				</div>
				<div class="col-md-3">
				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" onclick="kishan(this);">Not rumor'.$results['nrno'].'>
				</div>
				<div class="col-md-3">
				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No'.$results['adminrno'].'>
				</div>
				</div><!-- end of row-->
						
						</div><!--end of optionclass-->
					</div>
					';
					$sql2="select login.name from login,news where login.id=news.uid && nid=:nid";
					$stmto=$db->prepare($sql2) or die("not run");
					$stmto->execute(array(':nid'=>$results['nid']));
					$res=$stmto->fetch();
					$res['name'];
					echo '<div class="postname">Sender Name '.$res['name'].'</div>';
					echo'
				</div><a href="form.php?comment=1&&nid='.$results['nid'].'" id="comment">Comment on this</a>';}
				echo '</div><!--end of contain-->';}
				
			?>
			<script>
				function kishan(a)
				{
					var option=a.value;
					var nid = $(a).attr('data-id');
					var title=$(a).attr('data-tittle');
					var uid =$('#user_id').val();
				
					$.ajax({
							url:'ajax',
							method:'get',
							data:'option='+option+'&nid='+nid+'&uid='+uid+'&rating=yes',
							success:function(res){
								if(res=='Match found')
								{
								
								}
								else
								{
									alert("ok");
								}
							},
					});
				}
			</script>
		</div>
		<div class="col-lg-3 col-md-3">
		</div>
	</div>

</center>
	</div><!--end of data--></td>
</tr>
<td>&nbsp;
</table>
</table><center>
<button id="truth">Truth</button>
<button id="fake">Fake</button>
<button id="another">Another</button>
</center>
	</div>	
<?php

require_once "kfooter.php";
?>
<style type="text/css">
	.navbar
	{
		margin-top: -62px;
	}
</style>