<?php

include("header.php");  ?>


<!--about-->
<div id="about" class="about">
	<div class="container">
			<h1>About <span>us</span></h1>
			<h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod ut enim ad tempor incididunt ut labore et dolore magna aliqua.</h2>
			
	
	</div>
	</div>
	<div class="clearfix"></div>
<!--//about-->
<table border=1 width=90% bordercolor=#000055 style='border-collapse:collapse'  ALIGN=CENTER>
<tr>
<th bgcolor=#000055 > <font color=white ><h3 style="text-align: center";>BLOCK NAME</h3>

<tr>
<td >
<table border=0 align=center width=90%>
<tr>
<td > &nbsp;
<tr>
<td>&nbsp;
</table>
</table><center>
<button id="truth">Truth</button>
<button id="fake">Fake</button>
<button id="another">Another</button>
</center>
 
<!--contact-->
	
	<div class="contact-agile" id="contact">
		<h3>Contact <span>Us</span></h3>
			<div class="container">
						
				<form action="#" method="post" class="wow fadeInLeft animated" data-wow-delay=".5s">
					<div class="contact-grids1 agileinfo">
						<div class="contact-me ">
							<h4>Message</h4>
							<textarea name="Message" placeholder="" required=""> </textarea>
						</div>
						<div class="col-md-5 contact-form1">
							<h4>Name</h4>
							<input type="text" name="Name" placeholder="" required="">
						</div>
						<div class="col-md-5 contact-form1">
							<h4>Email</h4>
							<input type="email" name="Email" placeholder="" required="">
						</div>
						<div class="col-md-2 contact-form">
							<input type="submit" value="Submit">
						</div>
						<div class="clearfix"> </div>
					
					</div>
				</form>
						
			</div>
	</div>
<!--//contact-->

<?php
include("footer.php");


?>