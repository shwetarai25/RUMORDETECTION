<?php

 echo "add news";
?>