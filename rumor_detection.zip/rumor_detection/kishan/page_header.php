<!DOCTYPE html>
<html lang="en">
<head>
<title>Rumor Detection</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- css files -->

<link rel="stylesheet" href="css/bootkishan.min.css"  type="text/css" media="all">

<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootkishan.min.js"></script>

<link href="static/css/style.css" rel="stylesheet">


<!-- //css files -->
</head>
<body>
<?php
session_start();
if(isset($_SESSION['aemail'])&&($_SESSION['astatus']))
{
	?>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Rumor Detection</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">View User</a>
        </li>
      <li><a href="#">Add News</a></li>
      <li><a href="#">View News</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-log-out"></span> LogOut</a></li>
    </ul>
  </div>
</nav>
	<?php
}
elseif(isset($_SESSION['uemail'])&&($_SESSION['ustatus']))
{?>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Rumor Detection</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Post</a>
        </li>
      <li><a href="#">Profile</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
    </ul>
  </div>
</nav>
<?php
}
else
{
	?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Rumor Detection</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">About Us</a>
        </li>
      <li><a href="#">Contect Us</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a hrdf="index.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
<?php
}
?>