<?php

include("login_header.php");  ?>


<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>

</head>
<body>
<div class="header">
    <div class="slider">
        <div class="callbacks_container">
          <ul class="rslides" id="slider">
            
            <li>
              <div class="slider-info">
      <form action="query.php" method="get" name="f1">
  <div class="form-group">
    <?php if(isset($_REQUEST['wrong']))
    {
      echo "<p style='color:red'>Wrong Email id or Password</style></p>";
    } ?>
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name="email" placeholder="@gmail.com" required="required" onblur="">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd" name="password" placeholder="Only 8 charchter allowed" maxlength="8" required="required" onblur="">
  </div>
  <input type="hidden" name="login" value="submit">
  <button type="submit" class="btn btn-success btn-md" onclick="login();">Submit</button>
  <button type="reset" class="btn btn-default btn-md" >Reset</button>
  
</form>
</div>
 <div class="clearfix"></div>
      </div></div>
</body>
</html>
<script>
function login()
{
	var email=$('#email').val();
	var password=$('#password').val();
document.f1.submit();
}
	</script>
  