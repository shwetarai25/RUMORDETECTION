
//submit function
function Submit(){
 var emailRegex = /^[a-z0-9._]*\@[a-z]*\.[a-z]{2,5}$/;
 var fname = document.form.name.value,
 
  femail = document.form.email.value,
  fpassword = document.form.password.value,
  frepassword = document.form.repassword.value,
 
   
 if( fname == "" || !isNaN(fname))
   {
     document.form.name.focus();
  document.getElementById("errorBox").innerHTML = "Enter the first name";
     return false;
   }
    
   if (femail == "" )
 {
  document.form.email.focus();
  document.getElementById("errorBox").innerHTML = "Enter the email";
  return false;
  }else if(!emailRegex.test(femail)){
  document.form.email.focus();
  document.getElementById("errorBox").innerHTML = "Enter the valid email";
  return false;
  } 
 if(fpassword == "")
  {
   document.form.password.focus();
   document.getElementById("errorBox").innerHTML = "enter the password";
   return false;
  }
  if(fpassword !=frepassword){
   document.form.frepassword.focus();
   document.getElementById("errorBox").innerHTML = "password are not matching, re-enter again";
   return false;
   }
   
  if(fname != '' && femail != ''  && fpassword != '' && frepassword != ''){
   document.getElementById("errorBox").setAttribute="color","#00ff00"; 
   document.getElementById("errorBox").innerHTML = "form submitted successfully";
   }
     
}
