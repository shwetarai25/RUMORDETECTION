<?php
session_start();
require_once "conn.php";
if(isset($_SESSION['aemail'])&&($_SESSION['astatus']))
{
?>

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/datatablebootstrap4.min.css">
 <link rel="stylesheet" href="../bootsrap/css/bootstrap.min.css">
<script src="js/jquery-2.0.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>

<script src="js/datatable.min.js"></script>
<script>
	$(document).ready(function() {
    $('#showNews').DataTable();
} );
</script>

<button type="button" name="addPost" data-toggle="modal" data-target="addNews" class="btn btn-info btn-md">Add News</button>
<div class="container-fluid">
	<div class="showTable">
		<table id="showNews"><thead><th>No</th><th>Title</th><th>User</th><th>rumor</th><th>Non Rumor</th><th>Admin validation</th><th>status</th><th>Action</th></thead><tbody>
			<?php
			$sql='select * from news where row_delete=0';
			$stmt=$db->prepare($sql) or die("not Run");
			$stmt->execute();
			 $k=0;
			while($result=$stmt->fetch())
			{  $k++;
				echo '<tr><td>'.$k.'</td><td>'.$result['ntitle'].'</td><td>'.$result['uid'].'</td><td>'.$result['rno'].'</td><td>'.$result['nrno'].'</td><td>'.$result['adminrno'].'</td><td>'.$result['rstatus'].'</td><td></td></tr>';
			}
			?>

			</tbody>
		</table>
	</div>
</div>
<?php
}
?>