
<html>
<head>
	<title>Login Page</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-2.0.3.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>'
<?php
session_start();
require_once "conn.php";
$dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
	$date=$dt->format('Y-m-d H:i:s');
if(isset($_REQUEST['signup'])&&($_REQUEST['signup']=='user_signup'))
{
	if(isset($_REQUEST['insert'])&&($_REQUEST['insert']==1))
	{
		echo '<div class="row">
    <div class="container">
 <div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>Well done!</strong>  You successfully <strong>signup</strong>..
</div>
</div>
</div>';
echo '<meta http-equiv="refresh" content="2;url=http://localhost/internal/rumor_detection/index">';

	}

?>

<div class="container">
	<div class="col-md-12">
			<form action="#" method="get" name="f3">				
	<div class="form-group">
    <label for="name">User Name:</label>
    <input type="text" class="form-control" id="userName" name="userName" placeholder="" required="required">
  </div>
			<div class="form-group">
    <label for="email">Email ID:</label>
    <?php if(isset($_REQUEST['email'])&&($_REQUEST['email']==1))
    {
    	echo "<p style='color:red';>This email id all ready Exits into the record</style></p>";} ?>
    <input type="email" class="form-control" id="userEmail" name="userEmail" placeholder="@gmail.com" required="required">
  </div>
			 <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="userPassword" name="userPassword" placeholder="Only 8 charchter allowed" maxlength="8" required="required">
  </div>

			 <div class="form-group">
    <label for="pwd">Confirm Password:</label>
    <input type="password" class="form-control" id="userCPassword" name="userCPassword" placeholder="password and confirm both should be same" maxlength="8" required="required" onblur="">
  </div>
  <input type="hidden" name="signup" value="user_form">
				<div class="col-md-6">
				<button type="submit" class="btn btn-primary btn-group-justified" name="addEvent" value="submit" id="submit">
			<b>Submit</b></button>	
				</div>
				<div class="col-md-6">
					<button type="button" class="btn btn-primary btn-group-justified" name="addEvent" value="submit" id="addEvent">
			<b>Reset</b></button>
				</div>		
			</form>
		</div>
</div>

<?php
}if(isset($_REQUEST['signup']) && ($_REQUEST['signup']=='user_form'))
{
	$name=$_REQUEST['userName'];
	$email=$_REQUEST['userEmail'];
	$password=$_REQUEST['userPassword'];
	
	$sql2="select * from login where email=:email";
	$stmt2=$db->prepare($sql2);
	$stmt2->execute(array(':email'=>$email));
	$result=$stmt2->rowCount();
	if(!$result='0')
	{
		header("location:form?signup=user_signup&&email=1");
	}
	else{
	$sql='insert into login (name,email,password,status,operation_date,operation,row_delete) values(:name,:email,:password,:status,:operation_date,:operation,:row_delete)';
	$stmt=$db->prepare($sql) or die("not run");
	$stmt->execute(array(':name'=>$name,':email'=>$email,':password'=>$password,':status'=>'1',':operation_date'=>$date,':operation'=>'insert',':row_delete'=>'0'));
	//echo "ok";
	header("location:form?signup=user_signup&&insert=1");
	}
}
if(isset($_REQUEST['viewNews'])&&($_REQUEST['viewNews']==2))
{
	if(isset($_SESSION['aemail']))
	{

	}
}if(isset($_REQUEST['post'])&&($_REQUEST['post']=='addpost'))
{
	if(isset($_SESSION['uemail'])&&($_SESSION['ustatus']))
	{
		$post =$_REQUEST['mess'];
		$localIP = getHostByName(getHostName());
		$string=exec('getmac');
		$uid=$_SESSION['uid'];
		$mac=substr($string, 0, 17); 

		$sql="insert into news(ntitle,uid,uip,umac,operation_date,operation,row_delete) values(:ntitle,:uid,:uip,:umac,:operation_date,:operation,:row_delete)";
		$stmt=$db->prepare($sql) or die("not run");
		$stmt->execute(array(':ntitle'=>$post,':uid'=>$uid,':uip'=>$localIP,':umac'=>$mac,':operation_date'=>$date,':operation'=>'insert','row_delete'=>'0'));
		
			header("location:front_page?user=1&&insert=1");

	}
}

?>
