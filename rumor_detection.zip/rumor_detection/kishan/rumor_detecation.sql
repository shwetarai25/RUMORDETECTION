-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 14, 2018 at 06:51 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rumor_detecation`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(8) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `operation_date` datetime NOT NULL,
  `operation` varchar(8) NOT NULL,
  `row_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`, `status`, `operation_date`, `operation`, `row_delete`) VALUES
(1, 'Kishan Kumar', 'kishan@gmail.com', 'vikash', 2, '2018-02-13 00:00:00', 'insert', 0),
(2, 'Vikash Dewangan', 'vikash@gmail.com', 'ravi', 1, '2018-02-13 00:00:00', 'insert', 0),
(3, 'Ravi', 'ravi@gmail.com', 'kamran', 1, '2018-02-13 11:59:07', 'insert', 0),
(4, 'pooja', 'poojasahu29041996@gmail.com', '123', 2, '2018-02-14 00:00:00', 'insert', 0),
(5, 'shweta rai', 'shwetarai25051999@gmail.com', 'shweta25', 2, '2018-02-14 00:00:00', 'insert', 0),
(6, 'poonam sahu', 'poonam372sahu@gmail.com', 'poonam12', 2, '2018-02-14 00:00:00', 'insert', 0),
(7, 'yasmin', 'bushrayasmin1998@gmail.com', '123', 2, '2018-02-14 00:00:00', 'insert', 0);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `nid` int(11) NOT NULL AUTO_INCREMENT,
  `ntitle` varchar(500) NOT NULL,
  `uid` int(11) NOT NULL,
  `rno` int(11) NOT NULL DEFAULT '0',
  `rid` varchar(10000) DEFAULT NULL,
  `nrno` int(11) NOT NULL DEFAULT '0',
  `nrid` varchar(10000) DEFAULT NULL,
  `adminrno` int(11) NOT NULL DEFAULT '0',
  `adminrid` varchar(10000) DEFAULT NULL,
  `rstatus` int(11) NOT NULL DEFAULT '1',
  `uip` varchar(50) NOT NULL,
  `umac` varchar(50) NOT NULL,
  `operation_date` datetime NOT NULL,
  `operation` varchar(8) NOT NULL,
  `row_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`nid`, `ntitle`, `uid`, `rno`, `rid`, `nrno`, `nrid`, `adminrno`, `adminrid`, `rstatus`, `uip`, `umac`, `operation_date`, `operation`, `row_delete`) VALUES
(1, 'Bhilai is a good city', 2, 0, NULL, 1, ',3', 1, ',2', 1, '192.168.4.126', 'D4-BE-D9-C2-54-C2', '2018-02-13 00:00:00', 'insert', 0),
(2, 'hello', 3, 0, NULL, 0, NULL, 2, ',3,2', 1, '192.168.4.126', 'D4-BE-D9-C2-54-C2', '2018-02-13 13:28:29', 'insert', 0),
(3, 'kisdfhkjfh\r\n', 3, 0, NULL, 0, NULL, 1, ',2', 1, '192.168.4.126', 'D4-BE-D9-C2-54-C2', '2018-02-13 13:34:34', 'insert', 0),
(4, 'hghh', 3, 0, NULL, 1, ',2', 0, NULL, 1, '100.70.186.30', '00-1E-10-1F-00-00', '2018-02-13 21:50:33', 'insert', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
