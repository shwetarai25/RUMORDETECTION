<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-2.0.3.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<?php
session_start();
require_once "conn.php";
?>
<!--Modal start-->
           <div class="modal fade" id="addNews" tabindex="-1" role="dialog" aria-labelledby="memberModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">

                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                        <h4 class="modal-title" id="memberModalLabel">Add the News</h4>
                                    </div>
                                    <div class="modal-body">
                                  	<form action="form" method="get" name="f3">
                                  		<div class="form-group">
 					 <label for="post">post:</label>
  						<textarea class="form-control" rows="5" id="post" name="mess"></textarea>
						</div>
						<input type="hidden" value="addpost" name="post"/>
						
           		                 </form>
                                 </div>
                    			 <div class="modal-footer">
                                  <a class="btn btn-info" id="addpost" onclick="addpost();">post</a>
                                 <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>                                
                                 </div>
                                </div>
                            </div>
                        </div>
                        <!--end of modal-->
                        <script>
                        	function addpost()
                        	{
                        		var post=$('#post').val();
                        		if(post==''){
                        			alert("it can't be null");
                        		}
                        		else{
                        			document.f3.submit();
                        		}
                        	}
                        </script>
<?php
if(isset($_SESSION['aemail'])&&($_SESSION['astatus']))
{
echo "<li>Home</li>
<li><a href='form?viewNews=2'>View News</a></li>
<li><a href=''>User Detail</a></li>
<li>Contect</li>";
}
if(isset($_SESSION['uemail'])&&($_SESSION['ustatus']))
{
	if(isset($_REQUEST['insert'])&&($_REQUEST['insert']==1))
	{
		echo '<div class="row">
    <div class="container">
 <div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>Well done!</strong>  You successfully post your <strong>Message</strong>..
</div>
</div>
</div>';
	}
	echo "<li>Home</li>
	<li><button type='button' data-toggle='modal' data-target='#addNews'>Add News</button></li>
	<li></li>
	<li></li>
	<li></li>";
}
?>
<div class="container">
	<div class="col-lg-9 col-md-9">
		<h4>News</h4>
		<?php
		$sql="select * from news where row_delete=0 && rstatus=1 order by operation_date desc";
		$stmt=$db->prepare($sql) or die('not run');
		$stmt->execute();
		while($results=$stmt->fetch())
		{	
			$nid=$results['nid'];
			$r1=explode(',', $results['rid']);
			$r2=explode(',', $results['nrid']);
			$r3=explode(',', $results['adminrid']);

			if(in_array($_SESSION['uid'],$r3))
			{
					echo '<div class="row">
				<div class="col-md-12">
					<div class="messsage">'.$results['ntitle'].'</div>
					
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="option">

			<input type="radio" name="rumor'.$results['nid'].'"  value="1" onclick="kishan(this);">rumor'.$results['rno'].'

			<input type="radio" name="rumor'.$results['nid'].'" value="2" onclick="kishan(this);">Not rumor'.$results['nrno'].'

			<input type="radio" name="rumor'.$results['nid'].'" value="3" checked onclick="kishan(this);">Dont No'.$results['adminrno'].'

					<div class="adminview" style="width:30px;height:30px;background-color:#9E9E9E;border-radius:50%;"></div>
					</div><!--end of optionclass-->
				</div>
			</div>';

			}
			else if(in_array($_SESSION['uid'], $r2))
			{
					echo '<div class="row">
				<div class="col-md-12">
					<div class="messsage">'.$results['ntitle'].'</div>
					
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="option">
			<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" onclick="kishan(this);">rumor'.$results['rno'].'

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" checked onclick="kishan(this);">Not rumor'.$results['nrno'].'

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No'.$results['adminrno'].'

					<div class="adminview" style="width:30px;height:30px;background-color:#9E9E9E;border-radius:50%;"></div>
					</div><!--end of optionclass-->
				</div>
			</div>';
			}
			else if(in_array($_SESSION['uid'], $r1))
			{
					echo '<div class="row">
				<div class="col-md-12">
					<div class="messsage">'.$results['ntitle'].'</div>
					
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="option">
			<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" checked onclick="kishan(this);">rumor'.$results['rno'].'

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" onclick="kishan(this);">Not rumor'.$results['nrno'].'

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No'.$results['adminrno'].'

					<div class="adminview" style="width:30px;height:30px;background-color:#9E9E9E;border-radius:50%;"></div>
					</div><!--end of optionclass-->
				</div>
			</div>';
			}
			else{
		
			echo '<div class="row">
				<div class="col-md-12">
					<div class="messsage">'.$results['ntitle'].'</div>
					
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="option">
			<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" onclick="kishan(this);">rumor'.$results['rno'].'

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" onclick="kishan(this);">Not rumor'.$results['nrno'].'

			<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No'.$results['adminrno'].'

					<div class="adminview" style="width:30px;height:30px;background-color:#9E9E9E;border-radius:50%;"></div>
					</div><!--end of optionclass-->
				</div>
			</div>';}
		}
			
		?>
		<script>
			function kishan(a)
			{
				var option=a.value;
				var nid = $(a).attr('data-id');
				var title=$(a).attr('data-tittle');
				var uid =$('#user_id').val();
			
				$.ajax({
						url:'ajax',
						method:'get',
						data:'option='+option+'&nid='+nid+'&uid='+uid+'&rating=yes',
						success:function(res){
							if(res=='Match found')
							{
							
							}
							else
							{
								alert("ok");
							}
						},
				});
			}
		</script>
	</div>
	<div class="col-lg-3 col-md-3">
	</div>

</div>