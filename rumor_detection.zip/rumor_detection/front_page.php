<?php
require_once "page_header.php";
?>
<div class="header">
<html>
<head>
<style>
	.contain
	{ 
	
		height: 200px;
		border:solid 2px red;
	}
	
	.messtitle
	{
		
		 
		height: 40px;
		
		font-size:25px;
	}
	.postname
	{
		position:relative;
		top:60px;
	font-size:17px;
	color:black;
		left:90px;
     		
		margin-left:70%;
	}
	#comment
	{
		
		position:relative;
		top:60px;
	font-size:17px;
	color:black;
		left:90px;
		margin-left:80%;
		
	}
	#shweta
	{
		position: absolute;
		z-index: 9;
		margin-top: 200px;
		margin-left: 20%;
		color:white;
	
	}
</style>
</head>
<?php
require_once "conn.php";
?>
<!--Modal start-->
           <div class="modal fade" id="addNews" tabindex="-1" role="dialog" aria-labelledby="memberModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">

                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                        <h4 class="modal-title" id="memberModalLabel">Add the News</h4>
                                    </div>
                                    <div class="modal-body">
                                    <form action="form.php" method="get" name="f4">
           <div class="form-group">
           <label for="post">Type of Post:</label>
              <select name="type" class="form-control"><?php

              require_once('conn.php');
              $sql="select * from typeofrumors where row_delete=0";
              $stmt=$db->prepare($sql) or die("not run");
              $stmt->execute();
              while($res=$stmt->fetch())
              {
                echo '<option value='.$res['tid'].'>'.$res['tname'].'</option>';
              }
             ?>
                
              </select>
            </div>
          
           <div class="form-group">
           <label for="post">post:</label>
              <textarea class="form-control" rows="5" id="post" name="mess"></textarea>
            </div>
            <input type="hidden" value="addpost" name="post"/>
            
                               </form>
                                 </div>
                           <div class="modal-footer">
                                  <a class="btn btn-info" id="addpost" onclick="addost();">post</a>
                                 <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>                                
                                 </div>
                                </div>
                            </div>
                        </div>
                          <script>
                        	function addost()
                        	{
                        		var post=$('#post').val();
                        		if(post==''){
                        			alert("it can't be null");
                        		}
                        		else{
                        			document.f4.submit();
                        		}
                        	}
                        </script>
<?php
if(isset($_SESSION['aemail'])&&($_SESSION['astatus']))
{
}
if(isset($_SESSION['uemail'])&&($_SESSION['ustatus']))
{
	if(isset($_REQUEST['insert'])&&($_REQUEST['insert']==1))
	{
		echo '<div class="row">
    <div class="container">
 <div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>Well done!</strong>  You successfully post your <strong>Message</strong>..
</div>
</div>
</div>';
	}
}
?>
<div class="row">
	<div class="col-md-2">
	</div>
	<div class="col-md-8" id="shweta">
Search:
<input type="text" placeholder="Search.." name="search" class="form-control" id="search" onkeyup="ku(this);">
 <div id="kumar"></div>    <script>
     	function ku(a)
     	{
     		var k=a.value;
     		$.ajax({
        	url:'getData',
        	data:'title='+k,
        	type:'POST',
        	success:function(json){
        		$(".ajax").html(json);
        	//	$(".dayevent .showevent").html(json);
        	}
        });
}
     </script>

	</div>
	<div class="col-md-2">
	</div>

</div>
<br><br>
<center>
<div class="ajax">
<div class="container-fluid">
	<table style="margin-top:200px;" border=1 width=90% bordercolor=#000055 style='border-collapse:collapse'  ALIGN=CENTE >
<tr>
<th bgcolor=#000055 > 
	<font color=white ><h3 style="text-align: center";>LATEST NEWS</h3>
	</th>=
</tr>
<tr>
	
	<td style="position:relative;"><div class="data">
	<?php
			$sql="select * from news where row_delete=0 && rstatus=1 order by operation_date desc";
			$stmt=$db->prepare($sql) or die('not run');
			$stmt->execute();
			while($results=$stmt->fetch())
			{

				echo '<div class="contain">';
				$nid=$results['nid'];
				$r1=explode(',', $results['rid']);
				$r2=explode(',', $results['nrid']);
				$r3=explode(',', $results['adminrid']);

				if(in_array($_SESSION['uid'],$r3))
				{
						echo '<div class="row">
					<div class="col-md-12">
						<div class="messtitle">
						<div class="messsage">'.$results['ntitle'].'</div>
						</div><!--end of the messtitile-->
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="option">

				<input type="radio" name="rumor'.$results['nid'].'"  value="1" onclick="kishan(this);">rumor<button type="button" class="btn btn-danger btn-md">'.$results['rno'].'</button> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

				<input type="radio" name="rumor'.$results['nid'].'" value="2" onclick="kishan(this);">Not rumor<button type="button" class="btn btn-success btn-md">'.$results['nrno'].'</button> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

				<input type="radio" name="rumor'.$results['nid'].'" value="3" checked onclick="kishan(this);">Dont No<button type="button" class="btn btn-info btn-md">'.$results['adminrno'].'</button>';
				if($results['rno'] >0 || $results['nrno'] >0)
				{
				$total=$results['rno']+$results['nrno'];
				$tureth=($results['nrno']*100)/$total;
				$false=($results['rno']*100)/$total;
			?>	
	<style >
	.rating{
		width:<?php echo $false; ?>%;
		height: 20px;
		background-color: red;

	}
	.nrating{
		width:<?php echo $tureth; ?>%;
		height: 20px;
		position: relative;
		margin-bottom: -20px;
		background-color: green;	
	}
	</style><?php };

				echo'<div class="nrating"></div>
						<div class="rating"></div>

						</div><!--end of optionclass-->
					</div>
					';
					$sql2="select login.name from login,news where login.id=news.uid && nid=:nid";
					$stmto=$db->prepare($sql2) or die("not run");
					$stmto->execute(array(':nid'=>$results['nid']));
					$res=$stmto->fetch();
					$res['name'];
					echo '<div class="postname">Sender Name &nbsp;&nbsp;'.$res['name'].'</div>';
					echo'
				</div><a href="form.php?comment=1&&nid='.$results['nid'].'" id="comment">Comment on this</a>';

				}
				else if(in_array($_SESSION['uid'], $r2))
				{
						echo '<div class="row">
					<div class="col-md-12">
				<div class="messtitle">
						<div class="messsage">'.$results['ntitle'].'</div>
						</div><!--end of the messtitile-->
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="option">
				<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">
                   
				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" onclick="kishan(this);">rumor<button type="button" class="btn btn-danger btn-md">'.$results['rno'].'</button>
                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" checked onclick="kishan(this);">Not rumor<button type="button" class="btn btn-success btn-md">'.$results['nrno'].'</button>
                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No<button type="button" class="btn btn-info btn-md">'.$results['adminrno'].'</button>';
					if($results['rno'] >0 || $results['nrno'] >0)
				{
				$total=$results['rno']+$results['nrno'];
				$tureth=($results['nrno']*100)/$total;
				$false=($results['rno']*100)/$total;
				?>
	<style>
	.rating{
		width:<?php echo $false;?>%;
		height: 20px;
		background-color: red;

	}
	.nrating{
		width:<?php echo $tureth;?>%;
		height: 20px;
		position: relative;
		margin-bottom: -20px;
		background-color: green;	
	}
	</style><?php };

				echo'<div class="nrating"></div>
						<div class="rating"></div>

						</div><!--end of optionclass-->
					</div>
					';
					$sql2="select login.name from login,news where login.id=news.uid && nid=:nid";
					$stmto=$db->prepare($sql2) or die("not run");
					$stmto->execute(array(':nid'=>$results['nid']));
					$res=$stmto->fetch();
					$res['name'];
					echo '<div class="postname">Sender Name &nbsp;&nbsp;'.$res['name'].'</div>';
					echo'
				</div><a href="form.php?comment=1&&nid='.$results['nid'].'" id="comment">Comment on this</a>';
				}
				else if(in_array($_SESSION['uid'], $r1))
				{
						echo '<div class="row">
					<div class="col-md-12">
				<div class="messtitle">
						<div class="messsage">'.$results['ntitle'].'</div>
						</div><!--end of the messtitile-->
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="option">
				<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" checked onclick="kishan(this);">rumor<button type="button" class="btn btn-danger btn-md">'.$results['rno'].'</button>
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" onclick="kishan(this);">Not rumor<button type="button" class="btn btn-success btn-md">'.$results['nrno'].'</button>
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No<button type="button" class="btn btn-info btn-md">'.$results['adminrno'].'</button>';
				if($results['rno'] >0 || $results['nrno'] >0)
				{
				$total=$results['rno']+$results['nrno'];
				$tureth=($results['nrno']*100)/$total;
				$false=($results['rno']*100)/$total;
				?>
	<style >
	.rating{
		width:<?php echo $false; ?>%;
		height: 20px;
		background-color: red;

	}
	.nrating{
		width:<?php echo $tureth; ?>%;
		height: 20px;
		position: relative;
		margin-bottom: -20px;
		background-color: green;	
	}
	</style><?php };

				echo'<div class="nrating"></div>
						<div class="rating"></div>

						</div><!--end of optionclass-->
					</div>
					';
					$sql2="select login.name from login,news where login.id=news.uid && nid=:nid";
					$stmto=$db->prepare($sql2) or die("not run");
					$stmto->execute(array(':nid'=>$results['nid']));
					$res=$stmto->fetch();
					$res['name'];
					echo '<div class="postname">Sender Name &nbsp;&nbsp;'.$res['name'].'</div>';
					echo'
				</div><a href="form.php?comment=1&&nid='.$results['nid'].'" id="comment">Comment on this</a>';
				}
				else{
			
				echo '<div class="row">
					<div class="col-md-12">
				<div class="messtitle">
						<div class="messsage">'.$results['ntitle'].'</div>
						</div><!--end of the messtitile-->
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="option">
				<input type="hidden" value="'.$_SESSION['uid'].'" name="user_id" id="user_id">

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="1" onclick="kishan(this);">rumors<button type="button" class="btn btn-danger btn-md">'.$results['rno'].'</button> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="2" onclick="kishan(this);">Not rumor<button type="button" class="btn btn-success btn-md">'.$results['nrno'].'</button> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

				<input type="radio" name="rumor'.$results['nid'].'" data-id="'.$results['nid'].'" data-tittle="'.$results['ntitle'].'" value="3" onclick="kishan(this);">Dont No<button type="button" class="btn btn-info btn-md">'.$results['adminrno'].'</button>';
				if($results['rno'] >0 || $results['nrno'] >0)
				{
				$total=$results['rno']+$results['nrno'];
				$tureth=($results['nrno']*100)/$total;
				$false=($results['rno']*100)/$total;
				?>
	<style >
	.rating{
		width:<?php echo $false;?>%;
		height: 20px;
		background-color: red;

	}
	.nrating{
		width:<?php echo $tureth;?>%;
		height: 20px;
		position: relative;
		margin-bottom: -20px;
		background-color: green;	
	}
	</style><?php } ;

				echo'<div class="nrating"></div>
						<div class="rating"></div>
						</div><!--end of optionclass-->
					</div>
					';
					$sql2="select login.name from login,news where login.id=news.uid && nid=:nid";
					$stmto=$db->prepare($sql2) or die("not run");
					$stmto->execute(array(':nid'=>$results['nid']));
					$res=$stmto->fetch();
					$res['name'];
					echo '<div class="postname">Sender Name '.$res['name'].'</div>';
					echo'
				</div><a href="form.php?comment=1&&nid='.$results['nid'].'" id="comment">Comment on this</a>';}
				echo '</div><!--end of contain-->';}
				
			?>
			<script>
				function kishan(a)
				{
					var option=a.value;
					var nid = $(a).attr('data-id');
					var title=$(a).attr('data-tittle');
					var uid =$('#user_id').val();
				
					$.ajax({
							url:'ajax',
							method:'get',
							data:'option='+option+'&nid='+nid+'&uid='+uid+'&rating=yes',
							success:function(res){
								if(res=='Match found')
								{
								
								}
								else
								{
									  location.reload();
								}
							},
					});
				}
			</script>
		</div>
		<div class="col-lg-3 col-md-3">
		</div>
	</div>
</div>
</center>
	</div><!--end of data--></td>
</tr>
<td>&nbsp;
</table>
</table><center>
<button id="truth">Truth</button>
<button id="fake">Fake</button>
<button id="another">Another</button>
</center>
	</div>	
<?php

require_once "kfooter.php";
?>
<style type="text/css">
	.navbar
	{
		margin-top: -230px;
	}
</style>