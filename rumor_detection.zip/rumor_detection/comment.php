<?php 
 session_start();
 $conn = new mysqli("localhost", "root", "","rumor_detecation");
if (isset($_POST['submit']))
{
$email=$_REQUEST['email'];
$title=$_REQUEST['title'];
$msg=$_REQUEST['msg'];
$query = mysqli_query($conn,"INSERT INTO  commen(email,title,messag) VALUES('$email', '$title', '$msg')");

if($query)
 {
echo "<script>alert('YOU SEND COMMENT SUCCESSFULLY, THANKYOU');</script>";
}
else
 {
 echo "<script>alert('FAILED TO INSERT');</script>";
 }
 }
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

input[type=text], select, textarea {
    width: 50%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
</head>
<body>
<center>
<h3>Comment's</h3>
<label>You want to comment fill this form.</label> 
<div class="container">
  <form action="comment.php" method="post">
    <label for="fname">First Name</label><br>
    <input type="text" id="subject" name="email" placeholder="Enter Email"><br>
<label for="fname">Title</label><br>
    <input type="text" id="subject" name="title" placeholder="Enter Title"><br>

    <label for="subject">Message</label><br>
    <textarea id="subject" name="msg" placeholder="Write something.." style="height:200px"></textarea><br>

    <input name="submit" type="submit" value="Submit">
  </form>
</div>
</center>
</body>
</html>
