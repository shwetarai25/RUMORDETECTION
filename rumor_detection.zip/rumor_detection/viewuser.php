<?php
require_once "page_header.php";
?>

<div class="uper">
<?php

if(isset($_SESSION['aemail']))
{ 
	require_once "conn.php";
	?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php
if(isset($_REQUEST['delete'])&&($_REQUEST['delete']==5))
{
	echo '<div class="row">
    <div class="container">
 <div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>Well done!</strong>  You successfully post your <strong>Deleted the Post</strong>..
</div>
</div>
</div>';
}
?><br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<div class="container-fluid">
	<div class="showTable">
		<table id="user"  class="table table-striped table-bordered" cellspacing="0" width="100%"><thead><tr><th>No</th>
			
			<th>User</th>
			<th>Email</th>
			<th>status</th>
			<th>Action</th></tr>
		</thead><tfoot></tfoot><tbody>
			<?php
			$sql='select * from login where status <=1 && row_delete=0';
			$stmt=$db->prepare($sql) or die("not Run");
			$stmt->execute();
			 $k=0;
			while($result=$stmt->fetch())
			{  $k++;
				if(!$result['status']==1)
				{
					$status='Off';
				}
				else
				{
					$status='On';
				}
				
				echo '<tr><td>'.$k.'</td>
				<td>'.$result['name'].'</td>
				<td>'.$result['email'].'</td>
				<td><a href="form.php?status=2&&st='.$result['status'].'&&uid='.$result['id'].'" name="status" class="btn btn-warning btn-sm">'.$status.'</a></td>
				<td><a href="form.php?uid='.$result['id'].'&&delete=user" name="delete_news" class="btn btn-danger btn-sm">Delete</button></td>
				</tr>';
		}
			?>

			</tbody>
		</table>
	</div>
</div>
<script src="js/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
$(document).ready(function() {
    $('#user').DataTable();
} );
</script>

	<?php
}?>
</div>
<?php
require_once "kfooter.php";
?>


<style>

.navbar
{
	 margin-top: -35px;
}
}

</style>>