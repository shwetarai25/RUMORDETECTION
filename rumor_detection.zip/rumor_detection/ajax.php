<?php
	require_once "conn.php";
	$option=$_REQUEST['option'];
	$uid=$_REQUEST['uid'];
	$nid=$_REQUEST['nid'];
	$sql="select * from news where nid=:nid";
	$stmt=$db->prepare($sql) or die("not Run");
	$stmt->execute(array(':nid'=>$nid));
	$result=$stmt->fetch();
 		 if($option=='3')
				{	
					$back= $result['adminrid'];
					$new=$back.','.$uid;
					$k=$result['adminrno'];
					$sql='update news set adminrno=:ranking,adminrid=:id where nid=:nid';
				}
				if($option=='2')
				{
					$back= $result['nrid'];
							$new=$back.','.$uid;
					$k=	$result['nrno'];
					$sql='update news set nrno=:ranking,nrid=:id where nid=:nid';
				}
				if($option=='1')
				{
					$back=$result['rid'];
					 $new=$back.','.$uid;
					$k=	$result['rno'];
					$sql='update news set rno=:ranking,rid=:id where nid=:nid';
				}
			$k++;
			$k;
			$stmt=$db->prepare($sql) or die("Not run");	
	$r1=explode(',', $result['rid']);
	if (!in_array($uid, $r1))
 	 {
 	 	$stmt->execute(array(':nid'=>$nid,':ranking'=>$k,':id'=>$new));
 	 }
	else
  		{
  		echo "Match found";
  		}
  		$r2=explode(',', $result['nrid']);
  		if (!in_array($uid, $r2))
 	 {
 	 	$stmt->execute(array(':nid'=>$nid,':ranking'=>$k,':id'=>$new));
 	 }
	else
  		{
  		echo "Match found";
  		}
  		$r3=explode(',', $result['adminrid']);
  		if (!in_array($uid, $r3))
 	 {
 	 	$stmt->execute(array(':nid'=>$nid,':ranking'=>$k,':id'=>$new));
 	 }
	else
  		{
  		echo "Match found";
  		}
	

?>