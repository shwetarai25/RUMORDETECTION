<?php
require_once "page_header.php";
?>
<html>
<head>
	<title>Login Page</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-2.0.3.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>'
<?php
require_once "conn.php";
$dt = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
	$date=$dt->format('Y-m-d H:i:s');
if(isset($_REQUEST['signup'])&&($_REQUEST['signup']=='user_signup'))
{
	if(isset($_REQUEST['insert'])&&($_REQUEST['insert']==1))
	{
		echo '<div class="row">
    <div class="container">
 <div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>Well done!</strong>  You successfully <strong>signup</strong>..
</div>
</div>
</div>';
echo '<meta http-equiv="refresh" content="2;url=http://localhost/rumor_detecation/index.php">';

	}

?>
<center>
<div class ="header">
<div class="container">
	<div class="col-md-12">

			<form action="#" method="get" name="f3">				
	<div class="form-group" style="margin-top:150px">
    <label for="name">User Name:</label><br>
    <input type="text"  id="userName" name="userName" placeholder="" size="50%" height="20%" required="required">
  </div>
			<div class="form-group">
    <label for="email">Email ID:</label><br>
    <?php if(isset($_REQUEST['email'])&&($_REQUEST['email']==1))
    {
    	echo "<p style='color:red';>This email id all ready Exits into the record</style></p>";} ?>
    <input type="email"  id="userEmail"  name="userEmail"size="50%" placeholder="@gmail.com" required="required">
  </div>
			 <div class="form-group">
    <label for="pwd">Password:</label><br>
    <input type="password" id="userPassword" name="userPassword" size="50%" placeholder="Only 8 charchter allowed" maxlength="8" required="required">
  </div>

			 <div class="form-group">
    <label for="pwd">Confirm Password:</label><br>
    <input type="password" id="userCPassword" name="userCPassword" size="50%" placeholder="password and confirm both should be same" maxlength="8" required="required" onblur="">
  </div>
  <input type="hidden" name="signup" value="user_form">
				
				<button type="submit" class="btn btn-primary  name="addEvent" value="submit" id="submit">
			<b>Submit</b></button>
				
				
					<button type="button" class="btn btn-primary " name="addEvent" value="submit" id="addEvent">
			<b>Reset</b></button></center>
				
			</form>
		</div>
</div></div>

<?php
}if(isset($_REQUEST['signup']) && ($_REQUEST['signup']=='user_form'))
{
	$name=$_REQUEST['userName'];
	$email=$_REQUEST['userEmail'];
	$password=$_REQUEST['userPassword'];
	
	$sql2="select * from login where email=:email";
	$stmt2=$db->prepare($sql2);
	$stmt2->execute(array(':email'=>$email));
	$result=$stmt2->rowCount();
	if(!$result=='0')
	{
		//header("location:form?signup=user_signup&&email=1");
	?>
	 <script> window.location="form.php?signup=user_signup&&email=1";</script>
	 <?php
	}
	else{
	$sql='insert into login (name,email,password,status,operation_date,operation,row_delete) values(:name,:email,:password,:status,:operation_date,:operation,:row_delete)';
	$stmt=$db->prepare($sql) or die("not run");
	$stmt->execute(array(':name'=>$name,':email'=>$email,':password'=>$password,':status'=>'1',':operation_date'=>$date,':operation'=>'insert',':row_delete'=>'0'));
	//echo "ok";
//	header("location:form?signup=user_signup&&insert=1");
		?>
	 <script> window.location="form.php?signup=user_signup&&insert=1";</script>
	 <?php

	}
}
if(isset($_REQUEST['viewNews'])&&($_REQUEST['viewNews']==2))
{
	if(isset($_SESSION['aemail']))
	{

	}
}if(isset($_REQUEST['post'])&&($_REQUEST['post']=='addpost'))
{
	if(isset($_SESSION['uemail'])&&($_SESSION['ustatus']))
	{
		$post =$_REQUEST['mess'];
		$type=$_REQUEST['type'];
		$localIP = getHostByName(getHostName());
		$string=exec('getmac');
		$uid=$_SESSION['uid'];
		$mac=substr($string, 0, 17); 

		$sql="insert into news(ntitle,uid,uip,umac,operation_date,operation,row_delete,type) values(:ntitle,:uid,:uip,:umac,:operation_date,:operation,:row_delete,:type)";
		$stmt=$db->prepare($sql) or die("not run");
		$stmt->execute(array(':ntitle'=>$post,':uid'=>$uid,':uip'=>$localIP,':umac'=>$mac,':operation_date'=>$date,':operation'=>'insert','row_delete'=>'0',':type'=>$type));
		
	//		header("location:front_page?user=1&&insert=1");

		?>
	 <script> window.location="front_page.php?user=1&&insert=1";</script>
	 <?php
	

	}
}
if(isset($_REQUEST['status'])&&($_REQUEST['status']==1))
{
	echo $status=$_REQUEST['st'];
	echo $nid=$_REQUEST['id'];
	if(!$status==1)
	{
		$sql="update news set rstatus=1 where nid=:nid";
		$stmt=$db->prepare($sql);
		$stmt->execute(array(':nid'=>$nid));
		//header("location:viewNews.php");
		?>
	 <script> window.location="viewNews.php";</script>
	 <?php
		}
	else{
		$sql="update news set rstatus=0 where nid=:nid";
		$stmt=$db->prepare($sql);
		$stmt->execute(array(':nid'=>$nid));
		//header("location:viewNews.php");
		?>
	 <script> window.location="viewNews.php";</script>
	 <?php
	
	}

}
if(isset($_REQUEST['status'])&&($_REQUEST['status']==2))
{
	echo $status=$_REQUEST['st'];
	echo $id=$_REQUEST['uid'];
	if(!$status==1)
	{
		$sql="update login set status=1 where id=:id";
		$stmt=$db->prepare($sql);
		$stmt->execute(array(':id'=>$id));
		//header("location:viewNews.php");
		?>
	 <script> window.location="viewuser.php";</script>
	 <?php
		}
	else{
		$sql="update login set status=0 where id=:id";
		$stmt=$db->prepare($sql);
		$stmt->execute(array(':id'=>$id));
		//header("location:viewNews.php");
		?>
	 <script> window.location="viewuser.php";</script>
	 <?php
	
	}

}
if(isset($_REQUEST['delete'])&&($_REQUEST['delete']=='news'))
{
	$nid=$_REQUEST['id'];
	$sql="update news set row_delete=1 where nid=:nid";
	$stmt=$db->prepare($sql);
	$stmt->execute(array(':nid'=>$nid));
	//header("location:viewNews.php?delete=5");
	 ?>
	 <script> window.location="viewNews.php?delete=5";</script>
	 <?php
}
if(isset($_REQUEST['delete'])&&($_REQUEST['delete']=='user'))
{
	$id=$_REQUEST['uid'];
	$sql="update login set row_delete=1 where id=:id";
	$stmt=$db->prepare($sql);
	$stmt->execute(array(':id'=>$id));
	//header("location:viewNews.php?delete=5");
	 ?>
	 <script> window.location="viewuser.php?delete=5";</script>
	 <?php
}if(isset($_REQUEST['comment'])&&($_REQUEST['comment']==1))
{
	$nid=$_REQUEST['nid'];
	?>
	<div class ="header">
	<div class="container">
		<div class="commentall">
			<div class="col-md-3">
		</div>
		<div class="col-md-6">
			<form action="#" method="get" name="f5">
		<div class="form-group" style="margin-top:200px">
  <label for="comment">Comment:</label>
  <textarea class="form-control" rows="5" name="comment" id="comment"></textarea>
	</div>
	<input type="hidden" name="nid" value="<?php echo $nid; ?>">
	<input type="hidden" name="addcomment" value="ok">
	<button type="button" name="comment" class="btn btn-success btn"
	 onclick="checkok();">Comment</button>
	</form><br>
	<script>
		function checkok()
		{
			var comment=$('#comment').val();
			if(comment=='')
			{
				alert("Comment can't be Empty");
				$('#comment').focus();
			}
			else
			{
				document.f5.submit();
			}
		}
	</script>
</div><!--end of col-md-6-->
<div class="col-md-3">
		</div>
	</div>
</div><!--end of container-->
	<?php
}if(isset($_REQUEST['addcomment'])&&($_REQUEST['addcomment']))
{
	 $comment=$_REQUEST['comment'];
	 $uid=$_SESSION['uid'];
	 $nid=$_REQUEST['nid'];
	 $sql='insert into comment (cname,uid,nid,operation_date,operation,row_delete)values(:cname,:uid,:nid,:operation_date,:operation,:row_delete)';
	 $stmt=$db->prepare($sql)or die("not run");
	 $stmt->execute(array(':cname'=>$comment,':uid'=>$uid,':nid'=>$nid,':operation_date'=>$date,':operation'=>'insert',':row_delete'=>'0'));
	// header("location:front_page?user=1");
	 ?>
	 <script> window.location="front_page.php?user=1";</script>
	 <?php
}
?>
<?php
require_once "kfooter.php";
?>
<style>
	.navbar{
		margin-top: -30px;
	}
</style>