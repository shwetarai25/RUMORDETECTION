<?php
include("page_header.php");
?>
   <div class="header">
<div class="container">
  <div class="col-md-9 login">
    <form action="query.php" method="get" name="f1">
  <div class="form-group" style="margin-top: 200px;">
    <?php if(isset($_REQUEST['wrong']))
    {
      echo "<p style='color:red'>Wrong Email id or Password</style></p>";
    } ?><center>
    <label for="email">Email Address:</label><br>
    <input type="email" id="email" name="email" placeholder="@gmail.com" required="required" onblur="" size="50%">
  </div></center><center>
  <div class="form-group">
    <label for="pwd">Password:</label><br>
    <input type="password"  id="pwd" name="password" placeholder="Only 8 charchter allowed" maxlength="8" required="required" onblur="" size="50%">
  </div>
  <input type="hidden" name="login" value="submit">
  <button type="submit" class="btn btn-success btn-md" onclick="login();">Submit</button>
  <button type="reset" class="btn btn-default btn-md" id="go" >Reset</button>
  
</form>
</div>
</div>
</div>
 <div class="clearfix"></div>
      </div></div>
</body></div>
</html>
<script>
function login()
{
  var email=$('#email').val();
  var password=$('#password').val();
document.f1.submit();
}
  </script>
<body>
  <style>
    .login
    {
      width: 500px;
      height: 300px;
      padding: 20px;
      margin-left:150px;
    }
    button
    {
      margin-left:50px;
    }
  </style>

</body>
</html>

  
<?php
include("kfooter.php"); 
?>