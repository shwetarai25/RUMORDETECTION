<?php
session_start();
require_once "conn.php";
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$sql="select * from login where email=:email && password=:password";
$stmt=$db->prepare($sql) or die("not run");
$stmt->execute(array(':email'=>$email,':password'=>$password));
$result=$stmt->rowCount();
if(!$result==0)
{
	$results=$stmt->fetch();
	$status=$results['status'];
	if($status==2)
	{
		$_SESSION['aemail']=$results['email'];
		$_SESSION['astatus']=$results['status'];
		$_SESSION['aid']=$results['id'];
		header("location:home.php");
		?>
		<script>windows.location="location:home.php"</script>
		<?php
	}
	else if($status==1){
		$_SESSION['uemail']=$results['email'];
		$_SESSION['ustatus']=$results['status'];
		$_SESSION['uid']=$results['id'];
		header("location:front_page?user=1");
		?>
		<script>windows.location="front_page?user=1"</script>
		<?php
	}
	else{
		echo "your are not a vaild user";
	}
}
else
{
	header("location:index.php?wrong");
	?>
	<script>windows.location="index.php?wrong"</script>
	<?php
}


?>