// JavaScript Document
$(document).ready(function(e) {
    
if($( window ).width() >= 1000)
{
	//alert("hello");
	$('#slide-submenu').css("display", "none");
}

if($( window ).width() <= 767)
{	
	$('#slide-submenu').closest('.list-group').hide()
	$('.mini-submenu').fadeIn();
}

$(function(){
	$('#slide-submenu').on('click',function() {			        
        $(this).closest('.list-group').delay(0).slideUp();
        	$('.mini-submenu').fadeIn();
			
       
        
      });

	$('.mini-submenu').on('click',function(){		
        $(this).next('.list-group').toggle('slide');
        $('.mini-submenu').hide();
	});
});
});

