//custom.js
//for add the staff
		$(document).ready(function(){
			$('#Reg_button').click(function(){
			var Name = $('#Name').val();
			var Mobile= $('#Mobile').val();
			var Email=$('#Email').val();
			var Expart=$('#Expart').val();
			var Image=$('#Image').val();
			var Alt =$('#Alt').val();
			var Active=$('#Active').val();
			if(Name =='' || Mobile ==''|| Email=='' || Expart=='' || Image =='' || Alt =='')
			{
				alert ("Fill Every Filed");
			}
			else if(!Name.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/))
				{
					alert("wrong Name");
				}
				else if(!Mobile.match(/^([0-9]{10})*$/))
					{
						alert ("Moblie number should be in 10 digit && moblie Number hould start from 7");
					}
			else{
					document.f9.submit();
						}
						
		});
	});
        //add about

	$(document).ready(function(){
			$('#about_button').click(function(){
			var Name = $('#aboName').val();
			var Image=$('#aboImage').val();
			var Alt =$('#aboAlt').val();
			var Active=$('#Active').val();
			if(Name =='' || Image=='' || Alt =='')
			{
                       
				alert ("Fill Every Filed");
			}
			else{
					document.f8.submit();
						}
						
		});
	});






function checklog()
{
	$(document).ready(function(e)
	{
		var username=$('#userName').val();
		var password= $('#password').val();
		if(username == '' || password == '')
		{
			alert("Fill Both Feild");
		}
		else
		{
                
			$.ajax({
                    
				url:"checklogin.php",
				method:'post',
				data:{username:username, password:password},
				success:function(res){$('.dash').html(res)
				 if(res== 'ad')
					{
						$('#loginmodal').hide();
						location.href="login.php?a=1";	
					}
					else if(res =='us')
						{
							$('#loginmodal').hide();
						location.href="login.php?u=1";
						}
						},
				});
		}
	});
}
//read modal

$(document).ready(function(e) {
$('.read-more').click(function(e){
var No = $(this).data('read');
	$.ajax({
		url:'show_service.php',
		data:{No:No},
		success:function(res){$('.show').html(res)},
		error:function(res){window.console.log(res)}
		
		});
	});
});
function checkbooking()
{
	$(document).ready(function(){
		var date=$('#Date').val();
                alert(now());
		if(date == '')
		{
			alert ("fill Date");
		}
                
		else{
			document.f6.submit();
		}
	});
}

//modal delete
$(document).ready(function(e) {
		$('#modalDelete').on('show.bs.modal', function(e){
			var button = $(e.relatedTarget);
			var a = button.data('kishan');
			$(this).find('.btn-delete').attr('href', a);			
			});
});			
//for slider
$(document).ready(function(e) {
	$('.slider').waterwheelCarousel();

});
//for wow js
 wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
    document.getElementById('moar').onclick = function() {
      var section = document.createElement('section');
      section.className = 'section--purple wow fadeInDown';
      this.parentNode.insertBefore(section, this);
    };
//signup
function signupuser()
{
$(document).ready(function(){
			var Name = $('#uname').val();
			var Mobile= $('#umobile').val();
			var Email=$('#uemail').val();
			var Password=$('#pass').val();
                       
                        if(Name == '' || Mobile == '' || Email == '' || Password == '')
			{
				alert ("Fill all the field");
			}
			else if(!Mobile.match(/^([0-9]{10})*$/))
			{
			alert ("Moblie number should be in 10 digit moblie Number hould start from 7");
			}
                      else if(!Password.match(/^([A-Za-z0-9]{8})*$/))
                      {
                      alert("Password only have 8 charcter");}
			else {
				
			$.ajax({
				url:"Add.php",
				method:'post',
				data:{txtName:Name, txtMobile:Mobile, txtEmail:Email, txtPassword:Password,
                                signup_button:"signup_button"},
				success:function(data){$('.dash1').html(data)
				  if(data =='insert')
						{
						$('#signupmodal').hide();
						location.href="first.php";	
			
						}
						},
				});
			}
			});
}
//edit booking
function kishan()
{
	alert("db");
	var vikash = $(this).data('vikash');
	alert(vikash);
	$.ajax({
		url:'edit.php',
		data:{No:No, edit_booking:'2'},
		success:function(res){$('.editbooking').html(res)},
		error:function(res){window.console.log(res)}
		
		});
}
//Add equpment
function checkeq()
	{
		$(document).ready(function(){
			var Name= $('#eqName').val();
			var Use= $('#eqUse').val();
			var About=$('#eqAbout').val();
			var Image=$('#eqImage').val();
			var Alt=$('#eqAlt').val();
			if(Name =='' || Use == ''|| About == '' || Image =='' || Alt == '')
			{
				alert ("Fill All feield");
			}
			else {
				document.f7.submit();
			}
			});
	}