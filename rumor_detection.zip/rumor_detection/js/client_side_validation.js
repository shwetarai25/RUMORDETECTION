// JavaScript Document

//  modal triggering function
function triggerModal(pageTitle, pageBody, a)
{
	 $(".modal .modal-title").html(pageTitle); 
			  $(".modal .modal-body").html(pageBody); 
			  $(".modal").modal("show");
			  //$(".modal .modal-body").load(pageName);
			  //for focus
			  $('#myModal').on('hidden.bs.modal', function () {
				   a.focus();
			  });	 
}

//----------------------------special characters matching--------------------------
function specialCharValid(a)
{
	//alert("hello");
	if(a.value.length>0)
	 {
		var letters = /^[0-9A-Za-z_,/.\s-]+$/; 
		if((a.value).match(letters))
		{
	
		}
		else
		{
			 triggerModal("Invalid Character","Kindly use alphanumeric and symbol like &nbsp;<b>- , . / _</b>&nbsp; only.",a); 
		} //else
	}//if
} // close  of specialCharValid

//--  Numeric check
function numericValid(a)
 { 
 if(a.value.length>0)
		  {
			   var no = /^([0-9])*$/;  
			   if(a.value.match(no))  
				  {  
					   //return true;  
				  }
				else  
				  {  						
						triggerModal("Invalid Number","Only Numeric Value allowed.",a);
				  }  
				    
		 
		 }
 }
 
 	//  mobile no validation
 function mobileValidate(a)
{
    if(a.value.length>0)
		  {
			   var phoneno = /^([0-9]{10})*$/;  
			   if(a.value.match(phoneno))  
				  {  
				  }
				else  
				  {  
				     triggerModal("Invalid mobile number","Mobile number should be 10 digit number.",a); 
				  }  
				    
		 
		 }
   }
   
   // Email validation
 function emailValid(a)
 {
	 var x = a.value;
		if(x.length>0)
		{
			  var reg = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i 
			 // /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;-----------------old logic not work with double dot
	  
			  if (reg.test(a.value) == false) 
			  {
					triggerModal("Invalid Email id","Please enter correct email id.",a);  
			  }
			  else
			  {
				 // Correct data
			  }
		}//end of value check
}
