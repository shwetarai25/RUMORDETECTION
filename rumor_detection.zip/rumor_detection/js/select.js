function trtr()
{
	alert("lele");
}
function country_required(a)
{
	if(a.value >0)
	{
		if(country == 0)
		{
			 rcount++;
			 country = 1;
			 addMore();
			// alert(rcount);
		}
	}
}
function state_required(a)
{
	if(a.value >0)
	{
		if(state == 0)
		{
			 rcount++;
			 state = 1;
			 addMore();
			 /*alert(rcount);*/
		}
	}
}

//-----------------------------------------rquired count---------------
function required_count()
{
	
	rcount++;
	/*alert(rcount);*/
	
}
//--------------------bill address existance checking-----
function billAddressChecking(a)
{
	var temp = 0;
   var vendor_name = document.getElementById("vendor_name").value;
   var bill_address = a.value;
   //-----ajax
   var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       temp = xml.responseText;
				   if(temp>0)
				   {
						window.setTimeout(function () { 
					    a.focus();
					    }, 0);
						if(destroy==1)
						{
							 a.value= "";
							 destroy = 0;
						}
						else
						{
					         alert("Bill Address Already Exist..!");
					         a.value= ""; 
						}
				   }
				   else
				   {
				   }

		        }
	        }
	      xml.open("get","./admin/billAddressAvailibility.php?vendor_name=" + vendor_name + "&bill_address=" + bill_address,true)
	      xml.send();
   //-----ajax close----  
}
//--------------------Pan no existance checking-----
function panChecking(a)
{
   //var vendor_name = document.getElementById("vendor_name").value;
   var pan_no = a.value;
   //alert(pan_no);
   //-----ajax
   var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       var temp = xml.responseText;
				  //alert(temp);
				  if(temp == 0)
				  {
					  //then ok
				  }
				   else if(temp == 'AR')
 				   {
						alert("You Are Already Registered");
						window.location = '../select_vendor';  
				   }
				   else if(temp == 'E')
				   {
					   alert("Your Request Can Not Be Procced \n To Contibue Conatact Simplexengg1@gmail.com");
						window.location = '../error';
				   }
				   else
				   {
					  var rply =  confirm("You had already share the information partially \n with us \n if you want to continue from where you left off kindly Press OK. \n or if you want to start press cancel");
					  if(rply)
					  {
						  temp = parseInt(temp)+1;
						//alert('Clicked confirm');+
						window.location = '../vendor_registration/' + temp;  
					  }
					  else
					  {
						//alert('Clicked cancel');  
					  }
				   }//Else of temp checking
		        } // End of if of ready state
	        }//ready state change
	      xml.open("post","../admin/panNoAvailibility/" + pan_no,false);
	      xml.send();
   //-----ajax close----  
}
//------------------------------------Tan No Existance checking---------------------------
function tanChecking(a)
{
   var vendor_name = document.getElementById("vendor_name").value;
   var tan_no = a.value;
   //-----ajax
   var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       var temp = xml.responseText;
				  
				  if(temp>0)
				  {
					   if(destroy==1)
						  {
							  a.value = "";
							  destroy = 0;
						  }
						  else
						  {
							  window.setTimeout(function () {a.focus();}, 0);
							  window.setTimeout(function () {a.value="";}, 0);
							  alert("TAN No Registered with Anothor Vendor..!");
						  }
				   }
				   else
				   {
					   if(tanNo == 0)
						   {
							   rcount++;
							   tanNo = 1;
							   
						   }		   
						   addMore();
				   }
				

		        }
	        }
	      xml.open("get","./admin/tanNoAvailibility.php?vendor_name=" + vendor_name + "&tan_no=" + tan_no,true)
	      xml.send();
   //-----ajax close----  
}

//----------------------------special characters matching--------------------------
function special_check(a)
{
	if(a.value.length>0)
	 {
		var letters = /^[0-9A-Za-z()_,/. -]+$/; 
		if((a.value).match(letters))
		{
			if(a.id=='bill_address' && billAddress== 0)
			{
				rcount++;
				billAddress = 1;
				//alert(rcount);
			}
			//title_case(a);
			addMore();
			
		}
		else
		{
			if(destroy==1)
			{
				a.value = "";
				destroy = 0;
			}
			else
			{
				window.setTimeout(function () {a.focus();}, 0);
		  window.setTimeout(function () {a.value="";}, 0);
		   alert("Only Alphanumeric ( ) _ , / . - are Allowed...!");
			}
		   
		     
	    
		}
	}
}
function special_check_delete(a)
{
	if(a.value.length>0)
	var letters = /^[0-9A-Za-z()_,/. -]+$/; 
	if((a.value).match(letters))
	{
	}
	else
	{
	  alert("Only Alphanumeric,Space and ( ) _ , . / - are allowed....!\n");
	  a.value="";
	  window.setTimeout(function () { 
              a.focus();
               }, 0);
	}
}
//special check for vendor
function special_check_vendor(a)
{
	if(a.value.length>0)
	var letters = /^[A-Za-z(). -]+$/; 
	if((a.value).match(letters))
	{
		if(vendor_name==0)
		{
	     	rcount++;
			vendor_name = 1;
		}
		addMore();
	}
	else
	{
	  alert("Only Characters Space and ( )  .  - are allowed....!\n");
	  a.value="";
	  window.setTimeout(function () { 
              a.focus();
               }, 0);
	}
}

//------------------------------------------------Tiltle case---------------------

function title_case(a)
{
	 var x= (a.value).toLowerCase();
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       a.value=xml.responseText;
		        }
	        }
	      xml.open("get","./admin/title_case.php?txt=" + x,true)
	      xml.send();
	
} 
function title_case_simple(a)
{
	 var x= (a.value).toLowerCase();
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       a.value=xml.responseText;
		        }
	        }
	      xml.open("get","./admin/title_case_simple.php?txt=" + x,true)
	      xml.send();
	
} 
 
 function pincode_check(a)
 { 
 if(a.value.length>0)
		  {
			   var phoneno = /^([0-9]{6})*$/;  
			   if(a.value.match(phoneno))  
				  {  
					   //return true;  
				  }
				else  
				  {  
				      alert("Only Six Numeric Values are allowed.!");
					  window.setTimeout(function () { 
					  a.focus();
					   }, 0);
				  }  
				    
		 
		 }
 }
 
 
  //---------------------------------** Numeric check checking**////////////////////////////////
 function numeric_check(a)
 { 
 if(a.value.length>0)
		  {
			   var phoneno = /^([0-9])*$/;  
			   if(a.value.match(phoneno))  
				  {  
					   //return true;  
				  }
				else  
				  {  if(destroy==1)
					{
						a.value = "";
						destroy = 0;
					}
					else
					{
						a.value = "";
						window.setTimeout(function () {a.focus();}, 0);
				        alert("Only Numeric values are Allowed...!");
					}
				  }  
				    
		 
		 }
 }
 
  //---------------------------------** Numeric check checking**////////////////////////////////
 function decimal_check(a)
 { 
 if(a.value.length>0)
		  {
			   var phoneno = /^([0-9](.)?[0-9]?)*$/;  
			   if(a.value.match(phoneno))  
				  {  
					   //return true;  
				  }
				else  
				  {     
				        window.setTimeout(function () {a.focus();}, 0);
						a.value = "";
				        alert("Only Numeric values are Allowed...!");
				  }  
				    
		 
		 }
 }
 
 //------------------------------------------------------Conversion in Uppercase----------------
 function convert_upper(a)
 {
	 a.value = (a.value).toUpperCase();
	 if(a.value.length>0)
	var letters = /^[0-9A-Za-z]+$/; 
	if((a.value).match(letters))
	{
	}
	else
	{
		
		if(destroy==1)
						{
							 emailField.value= "";
							 destroy = 0;
						}
						else
						{
					          alert("Only Alphanumeric values  are allowed.....!\n");
	 						  a.value="";
							  window.setTimeout(function () { a.focus();}, 0);
						}
	 
	  
	}
 }
 
 //------------------------------------------------------Conversion in Lowercase----------------
 function convert_lower(a)
 {
	 a.value = (a.value).toLowerCase();
 }
 //-------------------------------------------------------------------------length calculation-------
 function len_cal(a)
 {
	 alert((a.value).length);
 }
 //-----------------form of business---*********************
 function fob(a)
        {
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       //document.getElementById("form_of_business").innerHTML=xml.responseText;
				   a.innerHTML=xml.responseText;
		        }
	        }
	      xml.open("get","./admin/form_of_business.php",true)
	      xml.send();
      }
  function ab()
  {
	  alert("hell9o");
  }
  function selectCountry(a)
        {	
		
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       a.innerHTML=xml.responseText;
		        }
	        }
	      xml.open("post","../admin/selectCountry",true)
	      xml.send();
      }
  //-------------------------------------------------------------------------------------**Select City function**------------------
   function selectCityStatic()
        {
	      var x=document.getElementById("state").value;
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       document.getElementById("city").innerHTML=xml.responseText;
		        }
	        }
	      xml.open("post","../admin/selectCity/" + x,true)
	      xml.send();
      }
	  function selectCity()
        {
	      var x=document.getElementById("state"+count).value;
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       document.getElementById("city"+count).innerHTML=xml.responseText;
		        }
	        }
	      xml.open("post","../admin/selectCity/" + x,true)
	      xml.send();
      }
	  
	  function selectCityStaticBranchOffice()
        {
	      var x=document.getElementById("stateBranch").value;
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       document.getElementById("cityBranch").innerHTML=xml.responseText;
		        }
	        }
	      xml.open("post","../admin/selectCity/" + x,true)
	      xml.send();
      }
	  //--------------------------------------------------------------------------------Select state Portion---------------------------
	  
	  function slectStateStatic()
        {
	      var x=document.getElementById("country").value;
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       document.getElementById("state").innerHTML=xml.responseText;
		        }
	        }
	      xml.open("post","../admin/selectState/" + x, true);
	      xml.send();
      }
	  function slectStateStaticBranchOffice()
        {
	      var x=document.getElementById("countryBranch").value;
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       document.getElementById("stateBranch").innerHTML=xml.responseText;
		        }
	        }
	      xml.open("post","../admin/selectState/" + x, true);
	      xml.send();
      }
	  function slectState()
        {
	      var x=document.getElementById("country"+count).value;
	      var xml=new XMLHttpRequest();
	      xml.onreadystatechange=function()
         	{
		      if(xml.readyState==4 && xml.status==200)
	        	{
			       document.getElementById("state"+count).innerHTML=xml.responseText;
		        }
	        }
	      xml.open("post","../admin/selectState/" + x, true)
	      xml.send();
      }


function check()
{
	var a = document.getElementById("rpass").value;
	var b = document.getElementById("pass").value;
	if(a==b)
	{
		document.getElementById("error").innerHTML="";
	}
	else
	{
		document.getElementById("rpass").value="";
		document.getElementById("rpass").focus();
		document.getElementById("error").innerHTML="Please Enter Same Password";
	}
}
//---------------------------------******---------------------------------****----Checking for mail availibility-------------------------------------
function mail_availibility()
{
	var x=document.getElementById("email").value;
	var xml=new XMLHttpRequest();
	xml.onreadystatechange=function()
	{
		if(xml.readyState==4 && xml.status==200)
		{
			if(xml.responseText ==1)
			{
			}
			else
			{
				document.getElementById("errormail").innerHTML = "Not Available";
				document.getElementById("email").value="";
				document.getElementById("email").focus();
			}
		}
	}
	xml.open("get","chechAvailibility.php?state=" + x,true)
	xml.send();
}

 function checkmail1(emailField)
 {
	 var x = emailField.value;
		if(x.length>0)
		{
			  var reg = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i 
			 // /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;-----------------old logic not work with double dot
	  
			  if (reg.test(emailField.value) == false) 
			  {
					  //emailField.value = "";
				  window.setTimeout(function () {
				  emailField.focus();
						}, 0); 
					  alert('Invalid Email Address......!\n if you want to fill another box you have to clear this box..');
					 /* document.getElementById("errormail").innerHTML="Please Enter correct email id";*/
			  }
			  else
			  {
				  if(email==0)
				  {
				  rcount++;
				  email= 1;
				  }
				 addMore();

			  }
		}//end of value check

}
 function checkmail(emailField)
 {
	 var x = emailField.value;
		if(x.length>0)
		{
			  var reg = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i 
			 // /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;-----------------old logic not work with double dot
	  
			  if (reg.test(emailField.value) == false) 
			  {
					  //emailField.value = "";
				  window.setTimeout(function () {
				  emailField.focus();
						}, 0); 
						if(destroy==1)
						{
							 emailField.value= "";
							 destroy = 0;
						}
						else
						{
					         alert('Invalid Email Address......!\n if you want to fill another box you have to clear this box..');
					         /*emailField.value= ""; */
						}
			  }
			  else
			  {
				  if(email==0)
				  {
				  rcount++;
				  email= 1;
				  }
				 addMore();
			  }
		}//end of value check

}
 //*------------------------------country_code_check--
 function country_code_check(a)
 {
	 if(a.value.length>0)
	var letters = /^[+]+[0-9]*$/; 
	if((a.value).match(letters))
	{
	}
	else
	{
	  alert("Only + and numbers are allowed....!\n");
	  a.value="";
	  window.setTimeout(function () { 
              a.focus();
               }, 0);
	}
 }
 
 
 
 //--------------------------------------**Check mail**----------------------------------------------------------------
function checkmobile(a)
{
    if(a.value.length>0)
		  {
			   var phoneno = /^([0-9]{10})*$/;  
			   if(a.value.match(phoneno))  
				  {  
					   //return true;  
					   if(mobile == 0)
					   {
						   rcount++;
						   mobile = 1;
					   }					   
					  addMore();
				  }
				else  
				  {  
				      if(destroy==1)
			             {
								a.value = "";
								destroy = 0;
					     }
						else
						 {
					          window.setTimeout(function () {a.focus();}, 0);							  
				              alert("Mobile No should be 10 Digit No.!");
						 }
				  }  
				    
		 
		 }
   }

//----------------------------------------------------------------------Check pan no
function chekpan_no(a)
{
 if(a.value.length>0)
   {
	    a.value = (a.value).toUpperCase();
	   var str1 = a.value;
	   var letters = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
	    if(str1.match(letters))  
        { 
		   panChecking(a);
		}
		else
		{
			if(destroy==1)
			{
				a.value = "";
				destroy = 0;
			}
			else
			{	
			  window.setTimeout(function () {a.value = "";}, 0);
			  window.setTimeout(function () {a.focus();}, 0);
			  alert("Please Enter Correct pan no..!\nFormat :- ABCDE1234A");
			}
		}

 }
}//-------------------------------------------------------Pan no end
//----------------------------------------------------------------------**Tan No cheking**-------------------------
function chektan_no(a)
{
	if(a.value.length>0)
	   {
	       a.value = (a.value).toUpperCase();
		   var str1 = a.value;
		   var letters = /^([a-zA-Z]){4}([0-9]){5}([a-zA-Z]){1}?$/;
			if(str1.match(letters))  
			 { 
			    //tanChecking(a);	   
			 }
			else
			 {
			   if(destroy==1)
				  {
					  a.value = "";
					  destroy = 0;
				  }
				  else
				  {
					  window.setTimeout(function () {a.focus();}, 0);
					  window.setTimeout(function () {a.value="";}, 0);
					 alert("Please Enter Correct pan no..!\nFormat :- ABCDE1234A");
				  }
		}
	  }
}
///----------------------------------------------------------------end of tan no

