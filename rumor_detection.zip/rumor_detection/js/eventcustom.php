//js
<?php session_start();
if(isset($_SESSION['anurag']) && isset($_SESSION['lastActivity']) && isset($_SESSION['expireTime']) )
{
  if($_SESSION['lastActivity'] < time() - $_SESSION['expireTime'])
  {
    //echo "<br>go to logout page";
    header("location:http://localhost/internal/process_logout");
  }
  else
  { //session  correct
    $_SESSION['lastActivity'] = time();

//this file use for insert,delete,edit opration of the eventtask
require_once "event_conn.php";
require_once "dbConnect_sqlserver.php";
?>

<script>
 alert("kishan");
$(document).ready(function() {
    var calendar = $('#calendar').fullCalendar({
   editable: true,
   selectable:true,
   header: {
    left: 'prev,next today',
    center: 'title',
    right: 'month,agendaWeek,agendaDay,listWeek'
   },
   views: {
        month: { buttonText: 'Month' },
        agendaWeek: { buttonText: 'Week' },
        agendaDay:{buttonText:'Day'},
        listWeek:{buttonText:'List Week'}
    },
   events:'selectEvent',
  
   //editable: true,
   eventDrop: function(event, delta,revertFunc) {
//alert(event.title + " was dropped on " + event.start.format());
 var start=event.start.format("YYYY-MM-DD HH:mm:ss");
 var end=event.start.format("YYYY-MM-DD HH:mm:ss");
 //alert(start);
       $.ajax({
   url: 'event_update',
   data: 'title='+ event.title+'&start='+ start +'&end='+ end +'&id='+ event.id ,
   type: "POST",
   success: function(json) {
    alert("Updated Successfully");
   }
   })

},
    eventResize:function(event){
  var start=event.start.format("YYYY-MM-DD HH:mm:ss");
 var end=event.start.format("YYYY-MM-DD HH:mm:ss");
     $.ajax({
   url: 'event_update',
   data: 'title='+ event.title+'&start='+ start +'&end='+ end +'&id='+ event.id ,
   type: "POST",
   success: function(json) {
    alert("Updated Successfully");
   },

   });

   },
    eventMouseover:function(event,jsEvent,view) {
    var operation= event.operation;
	$(".hoverevent").css("display", "block");
	$(".hoverevent #contentext").html(operation);
     },
     eventMouseout:function(event,jsEvent,view){
   	var operation= event.operation;
	$(".hoverevent").css("display", "none");
     },
 
dayClick: function(date, jsEvent, view, resourceObj) {
        alert('Date: ' + date.format());
        var start=event.start.format("YYYY-MM-DD");
        var selectdate=date.format("YYYY-MM-DD");
        alert('Date: ' + date.format());
        $.ajax({
        	url:'day_event',
        	data:'start='+start+'&selectdate='+selectdate,
        	type:'POST',
        	success:function(json){
        		$(".dayevent").css("display","block");
        		$(".dayevent .showevent").html(json);
        	}
        });
    },

   });

$('#eventadd').click(function(e){
//	alert("fdskjsh");
var No=2;
  $.ajax({
    url:'event_all',
    data:{No:No},
    success:function(check){$('.show').html(check)},
    error:function(check){window.console.log(check)}  
    });
  });

 });

  $('#StartDate').datepicker({
     minDate: '+0d',
     changeMonth: true,
     changeYear: true,
    dateFormat: 'yy-mm-dd',
    
 });
  $('#EndDate').datepicker({
     minDate: '+0d',
     changeMonth: true,
     changeYear: true,
   dateFormat: 'yy-mm-dd',
 });

$('#event_delete').on('show.bs.modal', function(e){         
    var button = $(e.relatedTarget);
    $(this).find('#eventDelete').attr('href', button.data('href'));
    });

      $('.editEvent').click(function(e){

var No =3;
var event_id=$(this).data('href');
  $.ajax({
    url:'event_all',
    data:{No:No,event_id:event_id},
    success:function(res){$('.show').html(res)},
    error:function(res){window.console.log(res)}
    
    });
  });





  function kishankumar()
    {
    var EventTitle=$('#Event_Title').val();
    var StartDate=$('#StartDate').val();
    var StartTime=$('#StartTime').val();
    var EndDate=$('#EndDate').val();
    var Department=$('#depart_change');
    //var employee=$('#emp_change').val();
    var EndTime=$('#EndTime').val();
   var Description=$('#txtDescription').val();

if(EventTitle == ''){
  alert("Field can not.. empty");
   $('#Event_Title').focus();
    }
     else if(Department == null)
    {
      alert("please select the employee or for all select all");
      $('#depart_change').focus();
    }
    else if (Description == '') {
    alert("Description Field can not.. empty");
   $('#txtDescription').focus();  
    }
    else if (StartDate == '') {
    alert("Field can not.. empty");
   $('#StartDate').focus(); 
    }
    else if(EndDate == '')
    {
      //alert("kumar");
      document.f3.submit();

    }
    else if(StartDate == EndDate)
  {
    //alert("kishan");
    if(!StartTime == '00:00'){
      //alert("kumar");
      if(StartTime > EndTime || StartTime == EndTime){
          alert("Event End Time is not valid");
          $('#EndTime').focus();
      }
      else{
      //  alert("kishan");
    document.f3.submit();
      }
      }
      else{
      //  alert("kishan");
    document.f3.submit();
      }
      }
    else
    {
    document.f3.submit();
    }
}


function kishan()
    {
    var EventTitle=$('#Event_Title').val();
    var StartDate=$('#StartDate').val();
    var StartTime=$('#StartTime').val();
    var EndDate=$('#EndDate').val();
    var Department=$('#department').val();
   // alert(employee);
    var EndTime=$('#EndTime').val();
   var Description=$('#txtDescription').val();

if(EventTitle == ''){
  alert("Field can not.. empty");
   $('#Event_Title').focus();
    }
    else if(Department == null)
    {
      alert("please select the employee or for all select all");
      $('#department').focus();
    }
    else if (Description == '') {
    alert("Description Field can not.. empty");
   $('#txtDescription').focus();  
    }
    else if (StartDate == '') {
    alert("Field can not.. empty");
   $('#StartDate').focus(); 
    }
    else if(EndDate == '')
    {
      //alert("kumar");
      document.f2.submit();

    }
    
    else if(StartDate == EndDate)
  {
    //alert("kishan");
    if(!StartTime == ''){
      //alert("kumar");
      if(StartTime > EndTime || StartTime == EndTime){
          alert("Event End Time is not valid");
          $('#EndTime').focus();
      }
      else{
      //  alert("kishan");
    document.f2.submit();
      }
      }
      else{
      //  alert("kishan");
    document.f2.submit();
      }
      }
    else
    {
      //alert("fhdk");
    document.f2.submit();
    }
}

<?php
}}
?>
</script>