<?php
include("page_header.php");
require_once "conn.php";
if(isset($_SESSION['aemail']))
{
	$a=$_SESSION['aemail'];
}
if(isset($_SESSION['uemail']))
{
	$a=$_SESSION['uemail'];
}
$sql="select * from login where email='$a'";
$stmt=$db->query($sql)or die("not run");
$res=$stmt->fetch();
$res['name'];
$res['email'];
$res['password'];
?>

<center>
<div class ="header">
<div class="container">
	<div class="col-md-12">

			<form action="#" method="get" name="f3">				
	<div class="form-group" style="margin-top:150px">
    <label for="name">User Name:</label><br>
    <input type="text"  id="userName" name="userName" value="<?php echo $res['name'] ?>" size="50%" height="20%" required="required">
  </div>
			<div class="form-group">
    <label for="email">Email ID:</label><br>
    <input type="email"  id="userEmail"  name="userEmail" value="<?php echo $res['email'] ?>" size="50%" placeholder="@gmail.com" required="required">
  </div>
			 <div class="form-group">
    <label for="pwd">Password:</label><br>
    <input type="text" id="userPassword" name="userPassword" value="<?php echo $res['password'] ?>" size="50%" placeholder="Only 8 charchter allowed" maxlength="8" required="required">
  </div>

		
  <input type="hidden" name="edit" value="update">
				<input type="hidden" name="id" value="<?php echo $res['id']; ?>">
				<button type="submit" class="btn btn-primary  name="addEvent" value="submit" id="submit">
			<b>Submit</b></button>
				
				
					<button type="button" class="btn btn-primary " name="addEvent" value="submit" id="addEvent">
			<b>Reset</b></button></center>
				
			</form>
		</div>
</div></div>
<?php

include("page_footer.php");
if(isset($_REQUEST['edit']) && ($_REQUEST['edit']=='update'))
{
	$a=$_REQUEST['userName'];
	$b=$_REQUEST['userEmail'];
	$c=$_REQUEST['userPassword'];
	$id=$_REQUEST['id'];
	$sql="update login set name=:name,email=:email,password=:password where id=:id";
	$stmt=$db->prepare($sql);
	$stmt->execute(array(':name'=>$a,':email'=>$b,':password'=>$c,':id'=>$id));
	?>
	<script>window.location="profile.php?update=1"</script>
	<?php
}
if(isset($_REQUEST['update']))
{
echo '<div class="row">
    <div class="container">
 <div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>Well done!</strong>  You successfully post your <strong>updated the profile</strong>..
</div>
</div>
</div>';
}