
<!DOCTYPE html>
<html lang="en">
<head>
<title>Rumor Detection</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Educational Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free web designs for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />

<!--// Meta tag Keywords -->
<!-- css files -->
<!-- //css files -->
<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Covered+By+Your+Grace" rel="stylesheet">
<!-- //online-fonts -->
</head>
<body>
<div class="main-w3layouts" id="home">
  <!--top-bar-->
  
  <!-- //Modal1 -->

  <!--Modal start-->
           <div class="modal fade" id="addNews" tabindex="-1" role="dialog" aria-labelledby="memberModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">

                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                        <h4 class="modal-title" id="memberModalLabel">Add the News</h4>
                                    </div>
                                    <div class="modal-body">
                                    <form action="form" method="get" name="f3">
           <div class="form-group">
           <label for="post">Type of Post:</label>
              <select name="type" class="form-control"><?php

              require_once('conn.php');
              $sql="select * from typeofrumors where row_delete=0";
              $stmt=$db->prepare($sql) or die("not run");
              $stmt->execute();
              while($res=$stmt->fetch())
              {
                echo '<option value='.$res['tid'].'>'.$res['tname'].'</option>';
              }
             ?>
                
              </select>
            </div>
          
           <div class="form-group">
           <label for="post">post:</label>
              <textarea class="form-control" rows="5" id="post" name="mess"></textarea>
            </div>
            <input type="hidden" value="addpost" name="post"/>
            
                               </form>
                                 </div>
                           <div class="modal-footer">
                                  <a class="btn btn-info" id="addpost" onclick="addpost();">post</a>
                                 <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>                                
                                 </div>
                                </div>
                            </div>
                        </div>
                        <!--end of modal-->
                        <script>
                          function addpost()
                          {
                            var post=$('#post').val();
                            if(post==''){
                              alert("it can't be null");
                            }
                            else{
                              document.f3.submit();
                            }
                          }
                        </script>

  <!--//top-bar-->
  <!-- navigation -->
<?php
session_start();
if(isset($_SESSION['aemail'])&&($_SESSION['astatus']))
{
  ?>
  <div class="top-search-bar">
    <div class="header-top-nav">
      <ul>
        <li><a href="end.php" style="color: white;"><i class="fa fa-key" aria-hidden="true"></i>Log Out</style>
        </a></li>
      </ul>
    </div>
  </div>
  
    <!-- navigation -->
      <div class ="top-nav">
        <nav class="navbar navbar-default">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              
            </div>
            <!-- navbar-header -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php" class="hvr-underline-from-center active">Home</a></li>
                <li><a href="viewNews.php" class="hvr-underline-from-center">VIEW NEWS</a></li>
                <li><a href="#" data-toggle='modal' data-target='#addNews' class="hvr-underline-from-center">ADD NEWS</a></li>
                <li><a href="profile.php" class="hvr-underline-from-center ">PROFILE</a></li>
              </ul>
            </div>
            <div class="clearfix"> </div> 
        </nav>
      </div>
  <!-- //navigation -->
<?php
}
else if(isset($_SESSION['uemail'])&&($_SESSION['ustatus']))
{?>
  <div class="top-search-bar">
    <div class="header-top-nav">
      <ul>
        <li><a href="end.php"><i class="fa fa-key" aria-hidden="true"></i>Log Out
        </a></li>
      </ul>
    </div>
  </div>
  
<div class ="top-nav">
        <nav class="navbar navbar-default">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              
            </div>
            <!-- navbar-header -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php" class="hvr-underline-from-center active">Home</a></li>
                <li><a href="view.php" class="hvr-underline-from-center ">VIEW USER</a></li>
               <li><a href="#" data-toggle='modal' data-target='#addNews'>Add News</a>
               </li>
   <li><a href="profile.php" class="hvr-underline-from-center ">PROFILE</a></li>
              </ul>
            </div>
            <div class="clearfix"> </div> 
        </nav>
      </div>
      <?php
}
else
{
  ?>
  <div class="top-search-bar">
    <div class="header-top-nav">
      <ul>
        <li><a href="index.php"><i class="fa fa-key" aria-hidden="true"></i>LOGIN</a></li>
        <li><a href="form.php?signup=user_signup" ><i class="fa fa-lock" aria-hidden="true"></i>SIGN UP</a></li>
      </ul>
    </div>
  </div>
        <div class ="top-nav">
        <nav class="navbar navbar-default">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              
            </div>
            <!-- navbar-header -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav navbar-right">
                <li><a href="index.html" class="hvr-underline-from-center active">Home</a></li>
                <li><a href="#about" class="hvr-underline-from-center scroll">About Us</a></li>
                <li><a href="#contact" class="hvr-underline-from-center scroll">Contact Us</a></li>
              </ul>
            </div>
            <div class="clearfix"> </div> 
        </nav>
      </div>
      <?php
}
?>
  <!-- //navigation -->

  <div class="header">
    
  
<!-- Slider -->
    <!-- //Slider -->
  </div>
</div>
<!--main-content-->



<!-- js -->
<script type="text/javascript" src="../static/js/jquery-2.1.4.min.js"></script>


<script src="../static/js/jquery.chocolat.js"></script>
    <link rel="stylesheet" href="../static/css/chocolat.css" type="text/css" media="screen">
    <!--light-box-files -->
    <script>
    $(function() {
      $('.gallery-grid a').Chocolat();
    });
    </script>
 <!-- required-js-files-->
    
              <link href="../static/css/owl.carousel.css" rel="stylesheet">
                  <script src="../static/js/owl.carousel.js"></script>
                      <script>
                  $(document).ready(function() {
                    $("#owl-demo").owlCarousel({
                      items : 1,
                      lazyLoad : true,
                      autoPlay : true,
                      navigation : false,
                      navigationText :  false,
                      pagination : true,
                    });
                  });
                  </script>
                 <!--//required-js-files-->

<script src="../static/js/responsiveslides.min.js"></script>
    <script>
        $(function () {
          $("#slider").responsiveSlides({
            auto: true,
            pager:false,
            nav: true,
            speed: 1000,
            namespace: "callbacks",
            before: function () {
              $('.events').append("<li>before event fired.</li>");
            },
            after: function () {
              $('.events').append("<li>after event fired.</li>");
            }
          });
        });
      </script>
      

<!-- start-smoth-scrolling -->
<script type="text/javascript" src="../static/js/move-top.js"></script>
<script type="text/javascript" src="../static/js/easing.js"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $(".scroll").click(function(event){   
      event.preventDefault();
      $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
    });
  });
</script>
<!-- start-smoth-scrolling -->

  <!-- bottom-top -->
  <!-- smooth scrolling -->
    <script type="..text/javascript">
      $(document).ready(function() {
      /*
        var defaults = {
        containerID: 'toTop', // fading element id
        containerHoverID: 'toTopHover', // fading element hover id
        scrollSpeed: 1200,
        easingType: 'linear' 
        };
      */                
      $().UItoTop({ easingType: 'easeOutQuart' });
      });
    </script>
    <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
  <!-- //smooth scrolling -->
  <!--// bottom-top -->
<script type="text/javascript" src="../static/js/bootstrap-3.1.1.min.js"></script>


</body>
</html>